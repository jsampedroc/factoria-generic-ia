package com.daycaremanagement.domain.repository;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

// Forzamos los Value Objects del dominio que siempre fallan
import com.daycaremanagement.domain.valueobject.*;
import com.daycaremanagement.domain.model.*;

import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente: ClassroomRepositoryPort
 * Componente ClassroomRepositoryPort
 */
@Slf4j
@Component
public class ClassroomRepositoryPort {

    public Object execute(Map<String, Object> params) {
        log.info("Iniciando ejecución de ClassroomRepositoryPort");
        try {
            // --- LÓGICA INYECTADA POR IA ---
            @Autowired
            private ClassroomRepository classroomRepository;

            public Classroom save(Classroom classroom) {
                return classroomRepository.save(classroom);
            }

            public Optional<Classroom> findById(ClassroomId id) {
                return classroomRepository.findById(id);
            }

            public List<Classroom> findAll() {
                return classroomRepository.findAll();
            }

            public void deleteById(ClassroomId id) {
                classroomRepository.deleteById(id);
            }

            public List<Classroom> findByAgeGroup(AgeGroup ageGroup) {
                return classroomRepository.findByAgeGroup(ageGroup);
            }

            public List<Classroom> findByTeacherId(StaffId teacherId) {
                return classroomRepository.findByTeacherId(teacherId);
            }

            public List<Classroom> findAvailableClassrooms() {
                return classroomRepository.findAvailableClassrooms();
            }
            // -------------------------------
            return null; 
        } catch (Exception e) {
            log.error("Error en ClassroomRepositoryPort: ", e);
            throw e;
        }
    }
}