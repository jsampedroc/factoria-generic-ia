package com.daycaremanagement.application.services;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

// Forzamos los Value Objects del dominio que siempre fallan
import com.daycaremanagement.domain.valueobject.*;
import com.daycaremanagement.domain.model.*;

import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente: ClassroomService
 * Componente ClassroomService
 */
@Slf4j
@Component
public class ClassroomService {

    public Object execute(Map<String, Object> params) {
        log.info("Iniciando ejecución de ClassroomService");
        try {
            // --- LÓGICA INYECTADA POR IA ---
            @Autowired
            private ClassroomRepositoryPort classroomRepositoryPort;

            @Autowired
            private StaffService staffService;

            public Classroom createClassroom(Classroom classroom) {
                validateClassroomData(classroom);
                validateTeacherExists(classroom.getTeacherId());
                return classroomRepositoryPort.save(classroom);
            }

            public Optional<Classroom> getClassroomById(ClassroomId id) {
                return classroomRepositoryPort.findById(id);
            }

            public List<Classroom> getAllClassrooms() {
                return classroomRepositoryPort.findAll();
            }

            public List<Classroom> getClassroomsByAgeGroup(AgeGroup ageGroup) {
                return classroomRepositoryPort.findByAgeGroup(ageGroup);
            }

            public List<Classroom> getClassroomsByTeacherId(StaffId teacherId) {
                return classroomRepositoryPort.findByTeacherId(teacherId);
            }

            public Classroom updateClassroom(ClassroomId id, Classroom updatedClassroom) {
                return classroomRepositoryPort.findById(id)
                        .map(existingClassroom -> {
                            existingClassroom.setName(updatedClassroom.getName());
                            existingClassroom.setCapacity(updatedClassroom.getCapacity());
                            existingClassroom.setAgeGroup(updatedClassroom.getAgeGroup());
                            existingClassroom.setTeacherId(updatedClassroom.getTeacherId());
                            return classroomRepositoryPort.save(existingClassroom);
                        })
                        .orElseThrow(() -> new ClassroomNotFoundException("Classroom not found with id: " + id));
            }

            public void deleteClassroom(ClassroomId id) {
                classroomRepositoryPort.deleteById(id);
            }

            public boolean isClassroomFull(ClassroomId id) {
                return classroomRepositoryPort.findById(id)
                        .map(classroom -> {
                            long currentEnrollment = classroomRepositoryPort.getCurrentEnrollment(id);
                            return currentEnrollment >= classroom.getCapacity();
                        })
                        .orElse(false);
            }

            private void validateClassroomData(Classroom classroom) {
                if (classroom.getName() == null || classroom.getName().trim().isEmpty()) {
                    throw new IllegalArgumentException("Classroom name is required");
                }
                if (classroom.getCapacity() <= 0) {
                    throw new IllegalArgumentException("Capacity must be greater than zero");
                }
                if (classroom.getAgeGroup() == null) {
                    throw new IllegalArgumentException("Age group is required");
                }
                if (classroom.getTeacherId() == null) {
                    throw new IllegalArgumentException("Teacher ID is required");
                }
            }

            private void validateTeacherExists(StaffId teacherId) {
                if (!staffService.getStaffById(teacherId).isPresent()) {
                    throw new StaffNotFoundException("Teacher not found with id: " + teacherId);
                }
            }
            // -------------------------------
            return null; 
        } catch (Exception e) {
            log.error("Error en ClassroomService: ", e);
            throw e;
        }
    }
}