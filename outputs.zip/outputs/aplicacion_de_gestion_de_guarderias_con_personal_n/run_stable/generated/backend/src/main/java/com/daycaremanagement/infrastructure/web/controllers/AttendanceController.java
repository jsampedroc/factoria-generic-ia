package com.daycaremanagement.infrastructure.web.controllers;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

// Forzamos los Value Objects del dominio que siempre fallan
import com.daycaremanagement.domain.valueobject.*;
import com.daycaremanagement.domain.model.*;

import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente: AttendanceController
 * Componente AttendanceController
 */
@Slf4j
@Component
public class AttendanceController {

    public Object execute(Map<String, Object> params) {
        log.info("Iniciando ejecución de AttendanceController");
        try {
            // --- LÓGICA INYECTADA POR IA ---
            @RestController
            @RequestMapping("/api/attendance")
            @Autowired
            private AttendanceService attendanceService;

            @PostMapping
            public ResponseEntity<AttendanceDTO> createAttendance(@RequestBody AttendanceDTO attendanceDTO) {
                Attendance attendance = convertToEntity(attendanceDTO);
                Attendance createdAttendance = attendanceService.createAttendance(attendance);
                return ResponseEntity.status(HttpStatus.CREATED).body(convertToDTO(createdAttendance));
            }

            @GetMapping("/{id}")
            public ResponseEntity<AttendanceDTO> getAttendance(@PathVariable AttendanceId id) {
                return attendanceService.getAttendanceById(id)
                        .map(attendance -> ResponseEntity.ok(convertToDTO(attendance)))
                        .orElse(ResponseEntity.notFound().build());
            }

            @GetMapping
            public ResponseEntity<List<AttendanceDTO>> getAllAttendance() {
                List<Attendance> attendanceList = attendanceService.getAllAttendance();
                List<AttendanceDTO> attendanceDTOs = attendanceList.stream()
                        .map(this::convertToDTO)
                        .collect(Collectors.toList());
                return ResponseEntity.ok(attendanceDTOs);
            }

            @GetMapping("/child/{childId}")
            public ResponseEntity<List<AttendanceDTO>> getAttendanceByChildId(@PathVariable ChildId childId) {
                List<Attendance> attendanceList = attendanceService.getAttendanceByChildId(childId);
                List<AttendanceDTO> attendanceDTOs = attendanceList.stream()
                        .map(this::convertToDTO)
                        .collect(Collectors.toList());
                return ResponseEntity.ok(attendanceDTOs);
            }

            @GetMapping("/date/{date}")
            public ResponseEntity<List<AttendanceDTO>> getAttendanceByDate(@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
                List<Attendance> attendanceList = attendanceService.getAttendanceByDate(date);
                List<AttendanceDTO> attendanceDTOs = attendanceList.stream()
                        .map(this::convertToDTO)
                        .collect(Collectors.toList());
                return ResponseEntity.ok(attendanceDTOs);
            }

            @GetMapping("/child/{childId}/date-range")
            public ResponseEntity<List<AttendanceDTO>> getAttendanceByChildAndDateRange(
                    @PathVariable ChildId childId,
                    @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
                    @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
                List<Attendance> attendanceList = attendanceService.getAttendanceByChildAndDateRange(childId, startDate, endDate);
                List<AttendanceDTO> attendanceDTOs = attendanceList.stream()
                        .map(this::convertToDTO)
                        .collect(Collectors.toList());
                return ResponseEntity.ok(attendanceDTOs);
            }

            @PutMapping("/{id}/check-in")
            public ResponseEntity<AttendanceDTO> checkIn(@PathVariable AttendanceId id, @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime checkInTime) {
                Attendance attendance = attendanceService.checkIn(id, checkInTime);
                return ResponseEntity.ok(convertToDTO(attendance));
            }

            @PutMapping("/{id}/check-out")
            public ResponseEntity<AttendanceDTO> checkOut(@PathVariable AttendanceId id, @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime checkOutTime) {
                Attendance attendance = attendanceService.checkOut(id, checkOutTime);
                return ResponseEntity.ok(convertToDTO(attendance));
            }

            @PutMapping("/{id}")
            public ResponseEntity<AttendanceDTO> updateAttendance(@PathVariable AttendanceId id, @RequestBody AttendanceDTO attendanceDTO) {
                Attendance attendance = convertToEntity(attendanceDTO);
                Attendance updatedAttendance = attendanceService.updateAttendance(id, attendance);
                return ResponseEntity.ok(convertToDTO(updatedAttendance));
            }

            @DeleteMapping("/{id}")
            public ResponseEntity<Void> deleteAttendance(@PathVariable AttendanceId id) {
                attendanceService.deleteAttendance(id);
                return ResponseEntity.noContent().build();
            }

            private Attendance convertToEntity(AttendanceDTO dto) {
                Attendance attendance = new Attendance();
                attendance.setId(dto.getId());
                attendance.setChildId(dto.getChildId());
                attendance.setDate(dto.getDate());
                attendance.setCheckInTime(dto.getCheckInTime());
                attendance.setCheckOutTime(dto.getCheckOutTime());
                attendance.setStatus(dto.getStatus());
                return attendance;
            }

            private AttendanceDTO convertToDTO(Attendance attendance) {
                AttendanceDTO dto = new AttendanceDTO();
                dto.setId(attendance.getId());
                dto.setChildId(attendance.getChildId());
                dto.setDate(attendance.getDate());
                dto.setCheckInTime(attendance.getCheckInTime());
                dto.setCheckOutTime(attendance.getCheckOutTime());
                dto.setStatus(attendance.getStatus());
                return dto;
            }
            // -------------------------------
            return null; 
        } catch (Exception e) {
            log.error("Error en AttendanceController: ", e);
            throw e;
        }
    }
}