package com.daycaremanagement.infrastructure.persistence.entity;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

// Forzamos los Value Objects del dominio que siempre fallan
import com.daycaremanagement.domain.valueobject.*;
import com.daycaremanagement.domain.model.*;

import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente: ChildJpaEntity
 * Componente ChildJpaEntity
 */
@Slf4j
@Component
public class ChildJpaEntity {

    public Object execute(Map<String, Object> params) {
        log.info("Iniciando ejecución de ChildJpaEntity");
        try {
            // --- LÓGICA INYECTADA POR IA ---
            @Id
            @GeneratedValue(strategy = GenerationType.IDENTITY)
            private Long id;

            @Column(nullable = false)
            private String firstName;

            @Column(nullable = false)
            private String lastName;

            @Column(nullable = false)
            private LocalDate dateOfBirth;

            @Column
            private String allergies;

            @Column
            private String specialNeeds;

            @Column(nullable = false)
            private LocalDate enrollmentDate;

            @Enumerated(EnumType.STRING)
            @Column(nullable = false)
            private ChildStatus status;

            public Long getId() {
                return id;
            }

            public void setId(Long id) {
                this.id = id;
            }

            public String getFirstName() {
                return firstName;
            }

            public void setFirstName(String firstName) {
                this.firstName = firstName;
            }

            public String getLastName() {
                return lastName;
            }

            public void setLastName(String lastName) {
                this.lastName = lastName;
            }

            public LocalDate getDateOfBirth() {
                return dateOfBirth;
            }

            public void setDateOfBirth(LocalDate dateOfBirth) {
                this.dateOfBirth = dateOfBirth;
            }

            public String getAllergies() {
                return allergies;
            }

            public void setAllergies(String allergies) {
                this.allergies = allergies;
            }

            public String getSpecialNeeds() {
                return specialNeeds;
            }

            public void setSpecialNeeds(String specialNeeds) {
                this.specialNeeds = specialNeeds;
            }

            public LocalDate getEnrollmentDate() {
                return enrollmentDate;
            }

            public void setEnrollmentDate(LocalDate enrollmentDate) {
                this.enrollmentDate = enrollmentDate;
            }

            public ChildStatus getStatus() {
                return status;
            }

            public void setStatus(ChildStatus status) {
                this.status = status;
            }
            // -------------------------------
            return null; 
        } catch (Exception e) {
            log.error("Error en ChildJpaEntity: ", e);
            throw e;
        }
    }
}