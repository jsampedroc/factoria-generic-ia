package com.daycaremanagement.domain.repository;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

// Forzamos los Value Objects del dominio que siempre fallan
import com.daycaremanagement.domain.valueobject.*;
import com.daycaremanagement.domain.model.*;

import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente: PaymentRepositoryPort
 * Componente PaymentRepositoryPort
 */
@Slf4j
@Component
public class PaymentRepositoryPort {

    public Object execute(Map<String, Object> params) {
        log.info("Iniciando ejecución de PaymentRepositoryPort");
        try {
            // --- LÓGICA INYECTADA POR IA ---
            @Autowired
            private PaymentRepository paymentRepository;

            public Payment save(Payment payment) {
                return paymentRepository.save(payment);
            }

            public Optional<Payment> findById(PaymentId id) {
                return paymentRepository.findById(id);
            }

            public List<Payment> findAll() {
                return paymentRepository.findAll();
            }

            public void deleteById(PaymentId id) {
                paymentRepository.deleteById(id);
            }

            public List<Payment> findByChildId(ChildId childId) {
                return paymentRepository.findByChildId(childId);
            }

            public List<Payment> findByStatus(PaymentStatus status) {
                return paymentRepository.findByStatus(status);
            }

            public List<Payment> findByDueDateBetween(LocalDate startDate, LocalDate endDate) {
                return paymentRepository.findByDueDateBetween(startDate, endDate);
            }

            public List<Payment> findByChildIdAndStatus(ChildId childId, PaymentStatus status) {
                return paymentRepository.findByChildIdAndStatus(childId, status);
            }
            // -------------------------------
            return null; 
        } catch (Exception e) {
            log.error("Error en PaymentRepositoryPort: ", e);
            throw e;
        }
    }
}