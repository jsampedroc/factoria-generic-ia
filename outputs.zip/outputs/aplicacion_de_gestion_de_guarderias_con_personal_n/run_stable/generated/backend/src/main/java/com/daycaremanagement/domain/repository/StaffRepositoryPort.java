package com.daycaremanagement.domain.repository;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

// Forzamos los Value Objects del dominio que siempre fallan
import com.daycaremanagement.domain.valueobject.*;
import com.daycaremanagement.domain.model.*;

import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente: StaffRepositoryPort
 * Componente StaffRepositoryPort
 */
@Slf4j
@Component
public class StaffRepositoryPort {

    public Object execute(Map<String, Object> params) {
        log.info("Iniciando ejecución de StaffRepositoryPort");
        try {
            // --- LÓGICA INYECTADA POR IA ---
            @Autowired
            private StaffRepository staffRepository;

            public Staff save(Staff staff) {
                return staffRepository.save(staff);
            }

            public Optional<Staff> findById(StaffId id) {
                return staffRepository.findById(id);
            }

            public List<Staff> findAll() {
                return staffRepository.findAll();
            }

            public void deleteById(StaffId id) {
                staffRepository.deleteById(id);
            }

            public List<Staff> findByRole(StaffRole role) {
                return staffRepository.findByRole(role);
            }

            public List<Staff> findByStatus(StaffStatus status) {
                return staffRepository.findByStatus(status);
            }

            public List<Staff> findByRoleAndStatus(StaffRole role, StaffStatus status) {
                return staffRepository.findByRoleAndStatus(role, status);
            }
            // -------------------------------
            return null; 
        } catch (Exception e) {
            log.error("Error en StaffRepositoryPort: ", e);
            throw e;
        }
    }
}