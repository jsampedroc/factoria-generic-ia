package com.daycaremanagement.infrastructure.web.controllers;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

// Forzamos los Value Objects del dominio que siempre fallan
import com.daycaremanagement.domain.valueobject.*;
import com.daycaremanagement.domain.model.*;

import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente: ClassroomController
 * Componente ClassroomController
 */
@Slf4j
@Component
public class ClassroomController {

    public Object execute(Map<String, Object> params) {
        log.info("Iniciando ejecución de ClassroomController");
        try {
            // --- LÓGICA INYECTADA POR IA ---
            @RestController
            @RequestMapping("/api/classrooms")
            @Autowired
            private ClassroomService classroomService;

            @PostMapping
            public ResponseEntity<ClassroomDTO> createClassroom(@RequestBody ClassroomDTO classroomDTO) {
                Classroom classroom = convertToEntity(classroomDTO);
                Classroom createdClassroom = classroomService.createClassroom(classroom);
                return ResponseEntity.status(HttpStatus.CREATED).body(convertToDTO(createdClassroom));
            }

            @GetMapping("/{id}")
            public ResponseEntity<ClassroomDTO> getClassroom(@PathVariable ClassroomId id) {
                return classroomService.getClassroomById(id)
                        .map(classroom -> ResponseEntity.ok(convertToDTO(classroom)))
                        .orElse(ResponseEntity.notFound().build());
            }

            @GetMapping
            public ResponseEntity<List<ClassroomDTO>> getAllClassrooms() {
                List<Classroom> classrooms = classroomService.getAllClassrooms();
                List<ClassroomDTO> classroomDTOs = classrooms.stream()
                        .map(this::convertToDTO)
                        .collect(Collectors.toList());
                return ResponseEntity.ok(classroomDTOs);
            }

            @GetMapping("/age-group/{ageGroup}")
            public ResponseEntity<List<ClassroomDTO>> getClassroomsByAgeGroup(@PathVariable AgeGroup ageGroup) {
                List<Classroom> classrooms = classroomService.getClassroomsByAgeGroup(ageGroup);
                List<ClassroomDTO> classroomDTOs = classrooms.stream()
                        .map(this::convertToDTO)
                        .collect(Collectors.toList());
                return ResponseEntity.ok(classroomDTOs);
            }

            @GetMapping("/teacher/{teacherId}")
            public ResponseEntity<List<ClassroomDTO>> getClassroomsByTeacher(@PathVariable StaffId teacherId) {
                List<Classroom> classrooms = classroomService.getClassroomsByTeacherId(teacherId);
                List<ClassroomDTO> classroomDTOs = classrooms.stream()
                        .map(this::convertToDTO)
                        .collect(Collectors.toList());
                return ResponseEntity.ok(classroomDTOs);
            }

            @PutMapping("/{id}")
            public ResponseEntity<ClassroomDTO> updateClassroom(@PathVariable ClassroomId id, @RequestBody ClassroomDTO classroomDTO) {
                Classroom classroom = convertToEntity(classroomDTO);
                Classroom updatedClassroom = classroomService.updateClassroom(id, classroom);
                return ResponseEntity.ok(convertToDTO(updatedClassroom));
            }

            @DeleteMapping("/{id}")
            public ResponseEntity<Void> deleteClassroom(@PathVariable ClassroomId id) {
                classroomService.deleteClassroom(id);
                return ResponseEntity.noContent().build();
            }

            @PostMapping("/{id}/assign-child/{childId}")
            public ResponseEntity<ClassroomDTO> assignChildToClassroom(@PathVariable ClassroomId id, @PathVariable ChildId childId) {
                Classroom classroom = classroomService.assignChildToClassroom(id, childId);
                return ResponseEntity.ok(convertToDTO(classroom));
            }

            @PostMapping("/{id}/remove-child/{childId}")
            public ResponseEntity<ClassroomDTO> removeChildFromClassroom(@PathVariable ClassroomId id, @PathVariable ChildId childId) {
                Classroom classroom = classroomService.removeChildFromClassroom(id, childId);
                return ResponseEntity.ok(convertToDTO(classroom));
            }

            private Classroom convertToEntity(ClassroomDTO dto) {
                Classroom classroom = new Classroom();
                classroom.setId(dto.getId());
                classroom.setName(dto.getName());
                classroom.setCapacity(dto.getCapacity());
                classroom.setAgeGroup(dto.getAgeGroup());
                classroom.setTeacherId(dto.getTeacherId());
                classroom.setChildrenIds(dto.getChildrenIds());
                return classroom;
            }

            private ClassroomDTO convertToDTO(Classroom classroom) {
                ClassroomDTO dto = new ClassroomDTO();
                dto.setId(classroom.getId());
                dto.setName(classroom.getName());
                dto.setCapacity(classroom.getCapacity());
                dto.setAgeGroup(classroom.getAgeGroup());
                dto.setTeacherId(classroom.getTeacherId());
                dto.setChildrenIds(classroom.getChildrenIds());
                return dto;
            }
            // -------------------------------
            return null; 
        } catch (Exception e) {
            log.error("Error en ClassroomController: ", e);
            throw e;
        }
    }
}