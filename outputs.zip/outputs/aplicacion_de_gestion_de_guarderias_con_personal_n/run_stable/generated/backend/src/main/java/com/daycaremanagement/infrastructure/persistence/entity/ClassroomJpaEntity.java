package com.daycaremanagement.infrastructure.persistence.entity;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

// Forzamos los Value Objects del dominio que siempre fallan
import com.daycaremanagement.domain.valueobject.*;
import com.daycaremanagement.domain.model.*;

import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente: ClassroomJpaEntity
 * Componente ClassroomJpaEntity
 */
@Slf4j
@Component
public class ClassroomJpaEntity {

    public Object execute(Map<String, Object> params) {
        log.info("Iniciando ejecución de ClassroomJpaEntity");
        try {
            // --- LÓGICA INYECTADA POR IA ---
            @Id
            @GeneratedValue(strategy = GenerationType.IDENTITY)
            private Long id;

            @Column(nullable = false, unique = true)
            private String name;

            @Column(nullable = false)
            private Integer capacity;

            @Enumerated(EnumType.STRING)
            @Column(nullable = false)
            private AgeGroup ageGroup;

            @Column(nullable = false)
            private Long teacherId;

            public Long getId() {
                return id;
            }

            public void setId(Long id) {
                this.id = id;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public Integer getCapacity() {
                return capacity;
            }

            public void setCapacity(Integer capacity) {
                this.capacity = capacity;
            }

            public AgeGroup getAgeGroup() {
                return ageGroup;
            }

            public void setAgeGroup(AgeGroup ageGroup) {
                this.ageGroup = ageGroup;
            }

            public Long getTeacherId() {
                return teacherId;
            }

            public void setTeacherId(Long teacherId) {
                this.teacherId = teacherId;
            }
            // -------------------------------
            return null; 
        } catch (Exception e) {
            log.error("Error en ClassroomJpaEntity: ", e);
            throw e;
        }
    }
}