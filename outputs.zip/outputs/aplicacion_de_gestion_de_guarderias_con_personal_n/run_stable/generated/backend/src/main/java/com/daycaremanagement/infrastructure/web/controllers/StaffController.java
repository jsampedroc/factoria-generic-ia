package com.daycaremanagement.infrastructure.web.controllers;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

// Forzamos los Value Objects del dominio que siempre fallan
import com.daycaremanagement.domain.valueobject.*;
import com.daycaremanagement.domain.model.*;

import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente: StaffController
 * Componente StaffController
 */
@Slf4j
@Component
public class StaffController {

    public Object execute(Map<String, Object> params) {
        log.info("Iniciando ejecución de StaffController");
        try {
            // --- LÓGICA INYECTADA POR IA ---
            @RestController
            @RequestMapping("/api/staff")
            @Autowired
            private StaffService staffService;

            @PostMapping
            public ResponseEntity<StaffDTO> createStaff(@RequestBody StaffDTO staffDTO) {
                Staff staff = convertToEntity(staffDTO);
                Staff createdStaff = staffService.createStaff(staff);
                return ResponseEntity.status(HttpStatus.CREATED).body(convertToDTO(createdStaff));
            }

            @GetMapping("/{id}")
            public ResponseEntity<StaffDTO> getStaff(@PathVariable StaffId id) {
                return staffService.getStaffById(id)
                        .map(staff -> ResponseEntity.ok(convertToDTO(staff)))
                        .orElse(ResponseEntity.notFound().build());
            }

            @GetMapping
            public ResponseEntity<List<StaffDTO>> getAllStaff() {
                List<Staff> staffList = staffService.getAllStaff();
                List<StaffDTO> staffDTOs = staffList.stream()
                        .map(this::convertToDTO)
                        .collect(Collectors.toList());
                return ResponseEntity.ok(staffDTOs);
            }

            @GetMapping("/role/{role}")
            public ResponseEntity<List<StaffDTO>> getStaffByRole(@PathVariable StaffRole role) {
                List<Staff> staffList = staffService.getStaffByRole(role);
                List<StaffDTO> staffDTOs = staffList.stream()
                        .map(this::convertToDTO)
                        .collect(Collectors.toList());
                return ResponseEntity.ok(staffDTOs);
            }

            @GetMapping("/status/{status}")
            public ResponseEntity<List<StaffDTO>> getStaffByStatus(@PathVariable StaffStatus status) {
                List<Staff> staffList = staffService.getStaffByStatus(status);
                List<StaffDTO> staffDTOs = staffList.stream()
                        .map(this::convertToDTO)
                        .collect(Collectors.toList());
                return ResponseEntity.ok(staffDTOs);
            }

            @GetMapping("/role/{role}/status/{status}")
            public ResponseEntity<List<StaffDTO>> getStaffByRoleAndStatus(
                    @PathVariable StaffRole role, 
                    @PathVariable StaffStatus status) {
                List<Staff> staffList = staffService.getStaffByRoleAndStatus(role, status);
                List<StaffDTO> staffDTOs = staffList.stream()
                        .map(this::convertToDTO)
                        .collect(Collectors.toList());
                return ResponseEntity.ok(staffDTOs);
            }

            @PutMapping("/{id}")
            public ResponseEntity<StaffDTO> updateStaff(@PathVariable StaffId id, @RequestBody StaffDTO staffDTO) {
                Staff staff = convertToEntity(staffDTO);
                Staff updatedStaff = staffService.updateStaff(id, staff);
                return ResponseEntity.ok(convertToDTO(updatedStaff));
            }

            @DeleteMapping("/{id}")
            public ResponseEntity<Void> deleteStaff(@PathVariable StaffId id) {
                staffService.deleteStaff(id);
                return ResponseEntity.noContent().build();
            }

            private Staff convertToEntity(StaffDTO dto) {
                Staff staff = new Staff();
                staff.setId(dto.getId());
                staff.setFirstName(dto.getFirstName());
                staff.setLastName(dto.getLastName());
                staff.setRole(dto.getRole());
                staff.setHireDate(dto.getHireDate());
                staff.setContactInfo(dto.getContactInfo());
                staff.setStatus(dto.getStatus());
                return staff;
            }

            private StaffDTO convertToDTO(Staff staff) {
                StaffDTO dto = new StaffDTO();
                dto.setId(staff.getId());
                dto.setFirstName(staff.getFirstName());
                dto.setLastName(staff.getLastName());
                dto.setRole(staff.getRole());
                dto.setHireDate(staff.getHireDate());
                dto.setContactInfo(staff.getContactInfo());
                dto.setStatus(staff.getStatus());
                return dto;
            }
            // -------------------------------
            return null; 
        } catch (Exception e) {
            log.error("Error en StaffController: ", e);
            throw e;
        }
    }
}