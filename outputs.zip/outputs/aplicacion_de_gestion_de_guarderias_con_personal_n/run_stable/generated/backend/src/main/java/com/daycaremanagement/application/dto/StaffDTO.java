package com.daycaremanagement.application.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;
import java.util.*;
import java.time.*;
import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente StaffDTO
 * POJO Entity managed by Factory
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StaffDTO {

    // --- LOGIC INJECTED BY IA ---
    private StaffId id;
    private String firstName;
    private String lastName;
    private StaffRole role;
    private LocalDate hireDate;
    private ContactInfo contactInfo;
    private StaffStatus status;

    public StaffId getId() {
        return id;
    }

    public void setId(StaffId id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public StaffRole getRole() {
        return role;
    }

    public void setRole(StaffRole role) {
        this.role = role;
    }

    public LocalDate getHireDate() {
        return hireDate;
    }

    public void setHireDate(LocalDate hireDate) {
        this.hireDate = hireDate;
    }

    public ContactInfo getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(ContactInfo contactInfo) {
        this.contactInfo = contactInfo;
    }

    public StaffStatus getStatus() {
        return status;
    }

    public void setStatus(StaffStatus status) {
        this.status = status;
    }
    // ----------------------------

}