package com.daycaremanagement.domain.repository;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

// Forzamos los Value Objects del dominio que siempre fallan
import com.daycaremanagement.domain.valueobject.*;
import com.daycaremanagement.domain.model.*;

import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente: ChildRepositoryPort
 * Componente ChildRepositoryPort
 */
@Slf4j
@Component
public class ChildRepositoryPort {

    public Object execute(Map<String, Object> params) {
        log.info("Iniciando ejecución de ChildRepositoryPort");
        try {
            // --- LÓGICA INYECTADA POR IA ---
            @Autowired
            private ChildRepository childRepository;

            public Child save(Child child) {
                return childRepository.save(child);
            }

            public Optional<Child> findById(ChildId id) {
                return childRepository.findById(id);
            }

            public List<Child> findAll() {
                return childRepository.findAll();
            }

            public void deleteById(ChildId id) {
                childRepository.deleteById(id);
            }

            public List<Child> findByStatus(ChildStatus status) {
                return childRepository.findByStatus(status);
            }
            // -------------------------------
            return null; 
        } catch (Exception e) {
            log.error("Error en ChildRepositoryPort: ", e);
            throw e;
        }
    }
}