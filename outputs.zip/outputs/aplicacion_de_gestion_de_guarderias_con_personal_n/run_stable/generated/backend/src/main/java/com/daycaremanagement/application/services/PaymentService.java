package com.daycaremanagement.application.services;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

// Forzamos los Value Objects del dominio que siempre fallan
import com.daycaremanagement.domain.valueobject.*;
import com.daycaremanagement.domain.model.*;

import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente: PaymentService
 * Componente PaymentService
 */
@Slf4j
@Component
public class PaymentService {

    public Object execute(Map<String, Object> params) {
        log.info("Iniciando ejecución de PaymentService");
        try {
            // --- LÓGICA INYECTADA POR IA ---
            @Autowired
            private PaymentRepositoryPort paymentRepositoryPort;

            @Autowired
            private ChildService childService;

            public Payment createPayment(Payment payment) {
                validatePaymentData(payment);
                validateChildExists(payment.getChildId());
                payment.setStatus(PaymentStatus.PENDING);
                payment.setInvoiceNumber(generateInvoiceNumber());
                return paymentRepositoryPort.save(payment);
            }

            public Payment processPayment(PaymentId id, PaymentMethod method) {
                return paymentRepositoryPort.findById(id)
                        .map(payment -> {
                            payment.setStatus(PaymentStatus.PAID);
                            payment.setPaymentDate(LocalDate.now());
                            payment.setMethod(method);
                            return paymentRepositoryPort.save(payment);
                        })
                        .orElseThrow(() -> new PaymentNotFoundException("Payment not found with id: " + id));
            }

            public Optional<Payment> getPaymentById(PaymentId id) {
                return paymentRepositoryPort.findById(id);
            }

            public List<Payment> getAllPayments() {
                return paymentRepositoryPort.findAll();
            }

            public List<Payment> getPaymentsByChildId(ChildId childId) {
                return paymentRepositoryPort.findByChildId(childId);
            }

            public List<Payment> getPaymentsByStatus(PaymentStatus status) {
                return paymentRepositoryPort.findByStatus(status);
            }

            public List<Payment> getPaymentsByDueDateRange(LocalDate startDate, LocalDate endDate) {
                return paymentRepositoryPort.findByDueDateBetween(startDate, endDate);
            }

            public List<Payment> getOverduePayments() {
                LocalDate today = LocalDate.now();
                List<Payment> pendingPayments = paymentRepositoryPort.findByStatus(PaymentStatus.PENDING);
                return pendingPayments.stream()
                        .filter(payment -> payment.getDueDate().isBefore(today))
                        .collect(Collectors.toList());
            }

            public Payment updatePayment(PaymentId id, Payment updatedPayment) {
                return paymentRepositoryPort.findById(id)
                        .map(existingPayment -> {
                            existingPayment.setAmount(updatedPayment.getAmount());
                            existingPayment.setDueDate(updatedPayment.getDueDate());
                            existingPayment.setStatus(updatedPayment.getStatus());
                            existingPayment.setMethod(updatedPayment.getMethod());
                            existingPayment.setInvoiceNumber(updatedPayment.getInvoiceNumber());
                            return paymentRepositoryPort.save(existingPayment);
                        })
                        .orElseThrow(() -> new PaymentNotFoundException("Payment not found with id: " + id));
            }

            public void deletePayment(PaymentId id) {
                paymentRepositoryPort.deleteById(id);
            }

            private void validatePaymentData(Payment payment) {
                if (payment.getAmount() == null || payment.getAmount().compareTo(BigDecimal.ZERO) <= 0) {
                    throw new IllegalArgumentException("Amount must be greater than zero");
                }
                if (payment.getDueDate() == null) {
                    throw new IllegalArgumentException("Due date is required");
                }
                if (payment.getChildId() == null) {
                    throw new IllegalArgumentException("Child ID is required");
                }
            }

            private void validateChildExists(ChildId childId) {
                if (!childService.getChildById(childId).isPresent()) {
                    throw new ChildNotFoundException("Child not found with id: " + childId);
                }
            }

            private String generateInvoiceNumber() {
                return "INV-" + System.currentTimeMillis() + "-" + UUID.randomUUID().toString().substring(0, 8);
            }
            // -------------------------------
            return null; 
        } catch (Exception e) {
            log.error("Error en PaymentService: ", e);
            throw e;
        }
    }
}