package com.daycaremanagement.application.services;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

// Forzamos los Value Objects del dominio que siempre fallan
import com.daycaremanagement.domain.valueobject.*;
import com.daycaremanagement.domain.model.*;

import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente: ChildService
 * Componente ChildService
 */
@Slf4j
@Component
public class ChildService {

    public Object execute(Map<String, Object> params) {
        log.info("Iniciando ejecución de ChildService");
        try {
            // --- LÓGICA INYECTADA POR IA ---
            @Autowired
            private ChildRepositoryPort childRepositoryPort;

            public Child createChild(Child child) {
                validateChildData(child);
                child.setStatus(ChildStatus.ACTIVE);
                child.setEnrollmentDate(LocalDate.now());
                return childRepositoryPort.save(child);
            }

            public Optional<Child> getChildById(ChildId id) {
                return childRepositoryPort.findById(id);
            }

            public List<Child> getAllChildren() {
                return childRepositoryPort.findAll();
            }

            public List<Child> getChildrenByStatus(ChildStatus status) {
                return childRepositoryPort.findByStatus(status);
            }

            public Child updateChild(ChildId id, Child updatedChild) {
                return childRepositoryPort.findById(id)
                        .map(existingChild -> {
                            existingChild.setFirstName(updatedChild.getFirstName());
                            existingChild.setLastName(updatedChild.getLastName());
                            existingChild.setDateOfBirth(updatedChild.getDateOfBirth());
                            existingChild.setAllergies(updatedChild.getAllergies());
                            existingChild.setSpecialNeeds(updatedChild.getSpecialNeeds());
                            existingChild.setStatus(updatedChild.getStatus());
                            return childRepositoryPort.save(existingChild);
                        })
                        .orElseThrow(() -> new ChildNotFoundException("Child not found with id: " + id));
            }

            public void deleteChild(ChildId id) {
                childRepositoryPort.deleteById(id);
            }

            private void validateChildData(Child child) {
                if (child.getFirstName() == null || child.getFirstName().trim().isEmpty()) {
                    throw new IllegalArgumentException("First name is required");
                }
                if (child.getLastName() == null || child.getLastName().trim().isEmpty()) {
                    throw new IllegalArgumentException("Last name is required");
                }
                if (child.getDateOfBirth() == null) {
                    throw new IllegalArgumentException("Date of birth is required");
                }
                if (child.getDateOfBirth().isAfter(LocalDate.now())) {
                    throw new IllegalArgumentException("Date of birth cannot be in the future");
                }
            }
            // -------------------------------
            return null; 
        } catch (Exception e) {
            log.error("Error en ChildService: ", e);
            throw e;
        }
    }
}