package com.daycaremanagement.domain.valueobject;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;
import java.util.*;
import java.time.*;
import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente ChildId
 * POJO Entity managed by Factory
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ChildId {

    // --- LOGIC INJECTED BY IA ---
    private Long value;

    public ChildId(Long value) {
        this.value = value;
    }

    public Long getValue() {
        return value;
    }

    public void setValue(Long value) {
        this.value = value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ChildId childId = (ChildId) o;
        return Objects.equals(value, childId.value);
    }

    @Override
    public int hashCode() {
        return Objects.hash(value);
    }

    @Override
    public String toString() {
        return "ChildId{" +
                "value=" + value +
                '}';
    }
    // ----------------------------

}