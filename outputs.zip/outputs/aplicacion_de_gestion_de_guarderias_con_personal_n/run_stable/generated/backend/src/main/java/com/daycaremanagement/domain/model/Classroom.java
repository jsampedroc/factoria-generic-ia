package com.daycaremanagement.domain.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;
import java.util.*;
import java.time.*;
import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente Classroom
 * POJO Entity managed by Factory
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Classroom {

    // --- LOGIC INJECTED BY IA ---
    private ClassroomId id;
    private String name;
    private Integer capacity;
    private AgeGroup ageGroup;
    private StaffId teacherId;

    public ClassroomId getId() {
        return id;
    }

    public void setId(ClassroomId id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public AgeGroup getAgeGroup() {
        return ageGroup;
    }

    public void setAgeGroup(AgeGroup ageGroup) {
        this.ageGroup = ageGroup;
    }

    public StaffId getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(StaffId teacherId) {
        this.teacherId = teacherId;
    }
    // ----------------------------

}