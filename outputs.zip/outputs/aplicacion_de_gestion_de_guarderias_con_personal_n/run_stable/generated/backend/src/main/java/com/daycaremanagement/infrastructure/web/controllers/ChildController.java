package com.daycaremanagement.infrastructure.web.controllers;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

// Forzamos los Value Objects del dominio que siempre fallan
import com.daycaremanagement.domain.valueobject.*;
import com.daycaremanagement.domain.model.*;

import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente: ChildController
 * Componente ChildController
 */
@Slf4j
@Component
public class ChildController {

    public Object execute(Map<String, Object> params) {
        log.info("Iniciando ejecución de ChildController");
        try {
            // --- LÓGICA INYECTADA POR IA ---
            @RestController
            @RequestMapping("/api/children")
            @Autowired
            private ChildService childService;

            @PostMapping
            public ResponseEntity<ChildDTO> createChild(@RequestBody ChildDTO childDTO) {
                Child child = convertToEntity(childDTO);
                Child createdChild = childService.createChild(child);
                return ResponseEntity.status(HttpStatus.CREATED).body(convertToDTO(createdChild));
            }

            @GetMapping("/{id}")
            public ResponseEntity<ChildDTO> getChild(@PathVariable ChildId id) {
                return childService.getChildById(id)
                        .map(child -> ResponseEntity.ok(convertToDTO(child)))
                        .orElse(ResponseEntity.notFound().build());
            }

            @GetMapping
            public ResponseEntity<List<ChildDTO>> getAllChildren() {
                List<Child> children = childService.getAllChildren();
                List<ChildDTO> childDTOs = children.stream()
                        .map(this::convertToDTO)
                        .collect(Collectors.toList());
                return ResponseEntity.ok(childDTOs);
            }

            @GetMapping("/status/{status}")
            public ResponseEntity<List<ChildDTO>> getChildrenByStatus(@PathVariable ChildStatus status) {
                List<Child> children = childService.getChildrenByStatus(status);
                List<ChildDTO> childDTOs = children.stream()
                        .map(this::convertToDTO)
                        .collect(Collectors.toList());
                return ResponseEntity.ok(childDTOs);
            }

            @PutMapping("/{id}")
            public ResponseEntity<ChildDTO> updateChild(@PathVariable ChildId id, @RequestBody ChildDTO childDTO) {
                Child child = convertToEntity(childDTO);
                Child updatedChild = childService.updateChild(id, child);
                return ResponseEntity.ok(convertToDTO(updatedChild));
            }

            @DeleteMapping("/{id}")
            public ResponseEntity<Void> deleteChild(@PathVariable ChildId id) {
                childService.deleteChild(id);
                return ResponseEntity.noContent().build();
            }

            private Child convertToEntity(ChildDTO dto) {
                Child child = new Child();
                child.setId(dto.getId());
                child.setFirstName(dto.getFirstName());
                child.setLastName(dto.getLastName());
                child.setDateOfBirth(dto.getDateOfBirth());
                child.setAllergies(dto.getAllergies());
                child.setSpecialNeeds(dto.getSpecialNeeds());
                child.setEnrollmentDate(dto.getEnrollmentDate());
                child.setStatus(dto.getStatus());
                return child;
            }

            private ChildDTO convertToDTO(Child child) {
                ChildDTO dto = new ChildDTO();
                dto.setId(child.getId());
                dto.setFirstName(child.getFirstName());
                dto.setLastName(child.getLastName());
                dto.setDateOfBirth(child.getDateOfBirth());
                dto.setAllergies(child.getAllergies());
                dto.setSpecialNeeds(child.getSpecialNeeds());
                dto.setEnrollmentDate(child.getEnrollmentDate());
                dto.setStatus(child.getStatus());
                return dto;
            }
            // -------------------------------
            return null; 
        } catch (Exception e) {
            log.error("Error en ChildController: ", e);
            throw e;
        }
    }
}