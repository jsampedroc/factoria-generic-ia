package com.daycaremanagement.application.services;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

// Forzamos los Value Objects del dominio que siempre fallan
import com.daycaremanagement.domain.valueobject.*;
import com.daycaremanagement.domain.model.*;

import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente: StaffService
 * Componente StaffService
 */
@Slf4j
@Component
public class StaffService {

    public Object execute(Map<String, Object> params) {
        log.info("Iniciando ejecución de StaffService");
        try {
            // --- LÓGICA INYECTADA POR IA ---
            @Autowired
            private StaffRepositoryPort staffRepositoryPort;

            public Staff createStaff(Staff staff) {
                validateStaffData(staff);
                staff.setStatus(StaffStatus.ACTIVE);
                staff.setHireDate(LocalDate.now());
                return staffRepositoryPort.save(staff);
            }

            public Optional<Staff> getStaffById(StaffId id) {
                return staffRepositoryPort.findById(id);
            }

            public List<Staff> getAllStaff() {
                return staffRepositoryPort.findAll();
            }

            public List<Staff> getStaffByRole(StaffRole role) {
                return staffRepositoryPort.findByRole(role);
            }

            public List<Staff> getStaffByStatus(StaffStatus status) {
                return staffRepositoryPort.findByStatus(status);
            }

            public List<Staff> getStaffByRoleAndStatus(StaffRole role, StaffStatus status) {
                return staffRepositoryPort.findByRoleAndStatus(role, status);
            }

            public Staff updateStaff(StaffId id, Staff updatedStaff) {
                return staffRepositoryPort.findById(id)
                        .map(existingStaff -> {
                            existingStaff.setFirstName(updatedStaff.getFirstName());
                            existingStaff.setLastName(updatedStaff.getLastName());
                            existingStaff.setRole(updatedStaff.getRole());
                            existingStaff.setContactInfo(updatedStaff.getContactInfo());
                            existingStaff.setStatus(updatedStaff.getStatus());
                            return staffRepositoryPort.save(existingStaff);
                        })
                        .orElseThrow(() -> new StaffNotFoundException("Staff not found with id: " + id));
            }

            public void deleteStaff(StaffId id) {
                staffRepositoryPort.deleteById(id);
            }

            private void validateStaffData(Staff staff) {
                if (staff.getFirstName() == null || staff.getFirstName().trim().isEmpty()) {
                    throw new IllegalArgumentException("First name is required");
                }
                if (staff.getLastName() == null || staff.getLastName().trim().isEmpty()) {
                    throw new IllegalArgumentException("Last name is required");
                }
                if (staff.getRole() == null) {
                    throw new IllegalArgumentException("Role is required");
                }
                if (staff.getContactInfo() == null) {
                    throw new IllegalArgumentException("Contact info is required");
                }
            }
            // -------------------------------
            return null; 
        } catch (Exception e) {
            log.error("Error en StaffService: ", e);
            throw e;
        }
    }
}