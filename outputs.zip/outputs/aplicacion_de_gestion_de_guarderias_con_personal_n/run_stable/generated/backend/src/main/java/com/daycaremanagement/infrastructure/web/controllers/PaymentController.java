package com.daycaremanagement.infrastructure.web.controllers;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

// Forzamos los Value Objects del dominio que siempre fallan
import com.daycaremanagement.domain.valueobject.*;
import com.daycaremanagement.domain.model.*;

import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente: PaymentController
 * Componente PaymentController
 */
@Slf4j
@Component
public class PaymentController {

    public Object execute(Map<String, Object> params) {
        log.info("Iniciando ejecución de PaymentController");
        try {
            // --- LÓGICA INYECTADA POR IA ---
            @RestController
            @RequestMapping("/api/payments")
            @Autowired
            private PaymentService paymentService;

            @PostMapping
            public ResponseEntity<PaymentDTO> createPayment(@RequestBody PaymentDTO paymentDTO) {
                Payment payment = convertToEntity(paymentDTO);
                Payment createdPayment = paymentService.createPayment(payment);
                return ResponseEntity.status(HttpStatus.CREATED).body(convertToDTO(createdPayment));
            }

            @PostMapping("/{id}/process")
            public ResponseEntity<PaymentDTO> processPayment(@PathVariable PaymentId id, @RequestParam PaymentMethod method) {
                Payment processedPayment = paymentService.processPayment(id, method);
                return ResponseEntity.ok(convertToDTO(processedPayment));
            }

            @GetMapping("/{id}")
            public ResponseEntity<PaymentDTO> getPayment(@PathVariable PaymentId id) {
                return paymentService.getPaymentById(id)
                        .map(payment -> ResponseEntity.ok(convertToDTO(payment)))
                        .orElse(ResponseEntity.notFound().build());
            }

            @GetMapping
            public ResponseEntity<List<PaymentDTO>> getAllPayments() {
                List<Payment> payments = paymentService.getAllPayments();
                List<PaymentDTO> paymentDTOs = payments.stream()
                        .map(this::convertToDTO)
                        .collect(Collectors.toList());
                return ResponseEntity.ok(paymentDTOs);
            }

            @GetMapping("/child/{childId}")
            public ResponseEntity<List<PaymentDTO>> getPaymentsByChildId(@PathVariable ChildId childId) {
                List<Payment> payments = paymentService.getPaymentsByChildId(childId);
                List<PaymentDTO> paymentDTOs = payments.stream()
                        .map(this::convertToDTO)
                        .collect(Collectors.toList());
                return ResponseEntity.ok(paymentDTOs);
            }

            @GetMapping("/status/{status}")
            public ResponseEntity<List<PaymentDTO>> getPaymentsByStatus(@PathVariable PaymentStatus status) {
                List<Payment> payments = paymentService.getPaymentsByStatus(status);
                List<PaymentDTO> paymentDTOs = payments.stream()
                        .map(this::convertToDTO)
                        .collect(Collectors.toList());
                return ResponseEntity.ok(paymentDTOs);
            }

            @GetMapping("/overdue")
            public ResponseEntity<List<PaymentDTO>> getOverduePayments() {
                List<Payment> payments = paymentService.getOverduePayments();
                List<PaymentDTO> paymentDTOs = payments.stream()
                        .map(this::convertToDTO)
                        .collect(Collectors.toList());
                return ResponseEntity.ok(paymentDTOs);
            }

            @GetMapping("/due-date-range")
            public ResponseEntity<List<PaymentDTO>> getPaymentsByDueDateRange(
                    @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
                    @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
                List<Payment> payments = paymentService.getPaymentsByDueDateRange(startDate, endDate);
                List<PaymentDTO> paymentDTOs = payments.stream()
                        .map(this::convertToDTO)
                        .collect(Collectors.toList());
                return ResponseEntity.ok(paymentDTOs);
            }

            @PutMapping("/{id}")
            public ResponseEntity<PaymentDTO> updatePayment(@PathVariable PaymentId id, @RequestBody PaymentDTO paymentDTO) {
                Payment payment = convertToEntity(paymentDTO);
                Payment updatedPayment = paymentService.updatePayment(id, payment);
                return ResponseEntity.ok(convertToDTO(updatedPayment));
            }

            @DeleteMapping("/{id}")
            public ResponseEntity<Void> deletePayment(@PathVariable PaymentId id) {
                paymentService.deletePayment(id);
                return ResponseEntity.noContent().build();
            }

            private Payment convertToEntity(PaymentDTO dto) {
                Payment payment = new Payment();
                payment.setId(dto.getId());
                payment.setAmount(dto.getAmount());
                payment.setDueDate(dto.getDueDate());
                payment.setPaymentDate(dto.getPaymentDate());
                payment.setStatus(dto.getStatus());
                payment.setMethod(dto.getMethod());
                payment.setInvoiceNumber(dto.getInvoiceNumber());
                payment.setChildId(dto.getChildId());
                return payment;
            }

            private PaymentDTO convertToDTO(Payment payment) {
                PaymentDTO dto = new PaymentDTO();
                dto.setId(payment.getId());
                dto.setAmount(payment.getAmount());
                dto.setDueDate(payment.getDueDate());
                dto.setPaymentDate(payment.getPaymentDate());
                dto.setStatus(payment.getStatus());
                dto.setMethod(payment.getMethod());
                dto.setInvoiceNumber(payment.getInvoiceNumber());
                dto.setChildId(payment.getChildId());
                return dto;
            }
            // -------------------------------
            return null; 
        } catch (Exception e) {
            log.error("Error en PaymentController: ", e);
            throw e;
        }
    }
}