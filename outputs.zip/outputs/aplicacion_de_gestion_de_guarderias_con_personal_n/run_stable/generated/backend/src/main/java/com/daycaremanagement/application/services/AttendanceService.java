package com.daycaremanagement.application.services;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

// Forzamos los Value Objects del dominio que siempre fallan
import com.daycaremanagement.domain.valueobject.*;
import com.daycaremanagement.domain.model.*;

import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente: AttendanceService
 * Componente AttendanceService
 */
@Slf4j
@Component
public class AttendanceService {

    public Object execute(Map<String, Object> params) {
        log.info("Iniciando ejecución de AttendanceService");
        try {
            // --- LÓGICA INYECTADA POR IA ---
            @Autowired
            private AttendanceRepositoryPort attendanceRepositoryPort;

            @Autowired
            private ChildService childService;

            public Attendance recordCheckIn(Attendance attendance) {
                validateAttendanceData(attendance);
                validateChildExists(attendance.getChildId());
                attendance.setStatus(AttendanceStatus.PRESENT);
                attendance.setCheckInTime(LocalDateTime.now());
                return attendanceRepositoryPort.save(attendance);
            }

            public Attendance recordCheckOut(AttendanceId id) {
                return attendanceRepositoryPort.findById(id)
                        .map(attendance -> {
                            attendance.setCheckOutTime(LocalDateTime.now());
                            return attendanceRepositoryPort.save(attendance);
                        })
                        .orElseThrow(() -> new AttendanceNotFoundException("Attendance record not found with id: " + id));
            }

            public Optional<Attendance> getAttendanceById(AttendanceId id) {
                return attendanceRepositoryPort.findById(id);
            }

            public List<Attendance> getAllAttendance() {
                return attendanceRepositoryPort.findAll();
            }

            public List<Attendance> getAttendanceByChildId(ChildId childId) {
                return attendanceRepositoryPort.findByChildId(childId);
            }

            public List<Attendance> getAttendanceByDate(LocalDate date) {
                return attendanceRepositoryPort.findByDate(date);
            }

            public List<Attendance> getAttendanceByChildIdAndDateRange(ChildId childId, LocalDate startDate, LocalDate endDate) {
                return attendanceRepositoryPort.findByChildIdAndDateBetween(childId, startDate, endDate);
            }

            public List<Attendance> getAttendanceByStatus(AttendanceStatus status) {
                return attendanceRepositoryPort.findByStatus(status);
            }

            public Attendance updateAttendance(AttendanceId id, Attendance updatedAttendance) {
                return attendanceRepositoryPort.findById(id)
                        .map(existingAttendance -> {
                            existingAttendance.setStatus(updatedAttendance.getStatus());
                            existingAttendance.setCheckInTime(updatedAttendance.getCheckInTime());
                            existingAttendance.setCheckOutTime(updatedAttendance.getCheckOutTime());
                            return attendanceRepositoryPort.save(existingAttendance);
                        })
                        .orElseThrow(() -> new AttendanceNotFoundException("Attendance record not found with id: " + id));
            }

            public void deleteAttendance(AttendanceId id) {
                attendanceRepositoryPort.deleteById(id);
            }

            public Map<ChildId, List<Attendance>> getMonthlyAttendanceReport(LocalDate month) {
                LocalDate startDate = month.withDayOfMonth(1);
                LocalDate endDate = month.withDayOfMonth(month.lengthOfMonth());
                
                List<Attendance> allAttendance = attendanceRepositoryPort.findByDateBetween(startDate, endDate);
                
                return allAttendance.stream()
                        .collect(Collectors.groupingBy(Attendance::getChildId));
            }

            private void validateAttendanceData(Attendance attendance) {
                if (attendance.getChildId() == null) {
                    throw new IllegalArgumentException("Child ID is required");
                }
                if (attendance.getDate() == null) {
                    throw new IllegalArgumentException("Date is required");
                }
                if (attendance.getDate().isAfter(LocalDate.now())) {
                    throw new IllegalArgumentException("Attendance date cannot be in the future");
                }
            }

            private void validateChildExists(ChildId childId) {
                if (!childService.getChildById(childId).isPresent()) {
                    throw new ChildNotFoundException("Child not found with id: " + childId);
                }
            }
            // -------------------------------
            return null; 
        } catch (Exception e) {
            log.error("Error en AttendanceService: ", e);
            throw e;
        }
    }
}