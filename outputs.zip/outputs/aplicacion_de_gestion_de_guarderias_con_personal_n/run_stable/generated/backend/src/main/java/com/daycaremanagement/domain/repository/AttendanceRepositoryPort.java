package com.daycaremanagement.domain.repository;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

// Forzamos los Value Objects del dominio que siempre fallan
import com.daycaremanagement.domain.valueobject.*;
import com.daycaremanagement.domain.model.*;

import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente: AttendanceRepositoryPort
 * Componente AttendanceRepositoryPort
 */
@Slf4j
@Component
public class AttendanceRepositoryPort {

    public Object execute(Map<String, Object> params) {
        log.info("Iniciando ejecución de AttendanceRepositoryPort");
        try {
            // --- LÓGICA INYECTADA POR IA ---
            @Autowired
            private AttendanceRepository attendanceRepository;

            public Attendance save(Attendance attendance) {
                return attendanceRepository.save(attendance);
            }

            public Optional<Attendance> findById(AttendanceId id) {
                return attendanceRepository.findById(id);
            }

            public List<Attendance> findAll() {
                return attendanceRepository.findAll();
            }

            public void deleteById(AttendanceId id) {
                attendanceRepository.deleteById(id);
            }

            public List<Attendance> findByChildId(ChildId childId) {
                return attendanceRepository.findByChildId(childId);
            }

            public List<Attendance> findByDate(LocalDate date) {
                return attendanceRepository.findByDate(date);
            }

            public List<Attendance> findByChildIdAndDateBetween(ChildId childId, LocalDate startDate, LocalDate endDate) {
                return attendanceRepository.findByChildIdAndDateBetween(childId, startDate, endDate);
            }

            public List<Attendance> findByStatus(AttendanceStatus status) {
                return attendanceRepository.findByStatus(status);
            }

            public Optional<Attendance> findByChildIdAndDate(ChildId childId, LocalDate date) {
                return attendanceRepository.findByChildIdAndDate(childId, date);
            }
            // -------------------------------
            return null; 
        } catch (Exception e) {
            log.error("Error en AttendanceRepositoryPort: ", e);
            throw e;
        }
    }
}