package com.daycaremanagement.infrastructure.persistence.entity;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

// Forzamos los Value Objects del dominio que siempre fallan
import com.daycaremanagement.domain.valueobject.*;
import com.daycaremanagement.domain.model.*;

import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente: StaffJpaEntity
 * Componente StaffJpaEntity
 */
@Slf4j
@Component
public class StaffJpaEntity {

    public Object execute(Map<String, Object> params) {
        log.info("Iniciando ejecución de StaffJpaEntity");
        try {
            // --- LÓGICA INYECTADA POR IA ---
            @Id
            @GeneratedValue(strategy = GenerationType.IDENTITY)
            private Long id;

            @Column(nullable = false)
            private String firstName;

            @Column(nullable = false)
            private String lastName;

            @Enumerated(EnumType.STRING)
            @Column(nullable = false)
            private StaffRole role;

            @Column(nullable = false)
            private LocalDate hireDate;

            @Embedded
            private ContactInfo contactInfo;

            @Enumerated(EnumType.STRING)
            @Column(nullable = false)
            private StaffStatus status;

            public Long getId() {
                return id;
            }

            public void setId(Long id) {
                this.id = id;
            }

            public String getFirstName() {
                return firstName;
            }

            public void setFirstName(String firstName) {
                this.firstName = firstName;
            }

            public String getLastName() {
                return lastName;
            }

            public void setLastName(String lastName) {
                this.lastName = lastName;
            }

            public StaffRole getRole() {
                return role;
            }

            public void setRole(StaffRole role) {
                this.role = role;
            }

            public LocalDate getHireDate() {
                return hireDate;
            }

            public void setHireDate(LocalDate hireDate) {
                this.hireDate = hireDate;
            }

            public ContactInfo getContactInfo() {
                return contactInfo;
            }

            public void setContactInfo(ContactInfo contactInfo) {
                this.contactInfo = contactInfo;
            }

            public StaffStatus getStatus() {
                return status;
            }

            public void setStatus(StaffStatus status) {
                this.status = status;
            }
            // -------------------------------
            return null; 
        } catch (Exception e) {
            log.error("Error en StaffJpaEntity: ", e);
            throw e;
        }
    }
}