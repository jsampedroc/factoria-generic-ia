package com.daycaremanagement.domain.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;
import java.util.*;
import java.time.*;
import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente ClassroomTest
 * POJO Entity managed by Factory
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ClassroomTest {

    // --- LOGIC INJECTED BY IA ---
    @Test
    void classroomCreation_ValidData_Success() {
        Classroom classroom = new Classroom();
        classroom.setId(new ClassroomId(1L));
        classroom.setName("Sunshine Room");
        classroom.setCapacity(20);
        classroom.setAgeGroup(AgeGroup.TODDLER);
        classroom.setTeacherId(new StaffId(1L));
        
        assertEquals(new ClassroomId(1L), classroom.getId());
        assertEquals("Sunshine Room", classroom.getName());
        assertEquals(20, classroom.getCapacity());
        assertEquals(AgeGroup.TODDLER, classroom.getAgeGroup());
        assertEquals(new StaffId(1L), classroom.getTeacherId());
    }

    @Test
    void classroomSettersAndGetters_WorkCorrectly() {
        Classroom classroom = new Classroom();
        
        ClassroomId id = new ClassroomId(2L);
        classroom.setId(id);
        classroom.setName("Rainbow Room");
        classroom.setCapacity(15);
        classroom.setAgeGroup(AgeGroup.PRESCHOOL);
        StaffId teacherId = new StaffId(3L);
        classroom.setTeacherId(teacherId);
        
        assertEquals(id, classroom.getId());
        assertEquals("Rainbow Room", classroom.getName());
        assertEquals(15, classroom.getCapacity());
        assertEquals(AgeGroup.PRESCHOOL, classroom.getAgeGroup());
        assertEquals(teacherId, classroom.getTeacherId());
    }

    @Test
    void classroomWithNullValues_HandledCorrectly() {
        Classroom classroom = new Classroom();
        
        assertNull(classroom.getId());
        assertNull(classroom.getName());
        assertEquals(0, classroom.getCapacity());
        assertNull(classroom.getAgeGroup());
        assertNull(classroom.getTeacherId());
    }

    @Test
    void ageGroupEnum_ValuesCorrect() {
        assertEquals("INFANT", AgeGroup.INFANT.name());
        assertEquals("TODDLER", AgeGroup.TODDLER.name());
        assertEquals("PRESCHOOL", AgeGroup.PRESCHOOL.name());
        assertEquals("SCHOOL_AGE", AgeGroup.SCHOOL_AGE.name());
        
        assertTrue(AgeGroup.INFANT.toString().contains("INFANT"));
    }

    @Test
    void classroomIdEquality_WorksCorrectly() {
        ClassroomId id1 = new ClassroomId(1L);
        ClassroomId id2 = new ClassroomId(1L);
        ClassroomId id3 = new ClassroomId(2L);
        
        assertEquals(id1, id2);
        assertNotEquals(id1, id3);
        assertEquals(id1.hashCode(), id2.hashCode());
        assertNotEquals(id1.hashCode(), id3.hashCode());
    }

    @Test
    void classroomIdToString_ContainsValue() {
        ClassroomId id = new ClassroomId(5L);
        String toString = id.toString();
        
        assertTrue(toString.contains("5"));
        assertTrue(toString.contains("ClassroomId"));
    }

    @Test
    void classroomCapacityValidation_NegativeCapacity_DefaultZero() {
        Classroom classroom = new Classroom();
        classroom.setCapacity(-5);
        
        assertEquals(-5, classroom.getCapacity());
    }

    @Test
    void classroomTeacherAssignment_ValidStaffId() {
        Classroom classroom = new Classroom();
        StaffId teacherId = new StaffId(10L);
        classroom.setTeacherId(teacherId);
        
        assertEquals(teacherId, classroom.getTeacherId());
    }
    // ----------------------------

}