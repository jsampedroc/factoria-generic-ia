package com.daycaremanagement.application.services;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

// Forzamos los Value Objects del dominio que siempre fallan
import com.daycaremanagement.domain.valueobject.*;
import com.daycaremanagement.domain.model.*;

import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente: PaymentServiceTest
 * Componente PaymentServiceTest
 */
@Slf4j
@Component
public class PaymentServiceTest {

    public Object execute(Map<String, Object> params) {
        log.info("Iniciando ejecución de PaymentServiceTest");
        try {
            // --- LÓGICA INYECTADA POR IA ---
            @Test
            void createPayment_ValidData_ReturnsPayment() {
                Payment payment = new Payment();
                payment.setAmount(new BigDecimal("100.00"));
                payment.setDueDate(LocalDate.now().plusDays(30));
                payment.setChildId(new ChildId(1L));
                
                when(childService.getChildById(any(ChildId.class))).thenReturn(Optional.of(new Child()));
                when(paymentRepositoryPort.save(any(Payment.class))).thenReturn(payment);
                
                Payment result = paymentService.createPayment(payment);
                
                assertNotNull(result);
                assertEquals(PaymentStatus.PENDING, result.getStatus());
                assertNotNull(result.getInvoiceNumber());
                verify(paymentRepositoryPort).save(payment);
            }

            @Test
            void createPayment_InvalidAmount_ThrowsException() {
                Payment payment = new Payment();
                payment.setAmount(new BigDecimal("0.00"));
                payment.setDueDate(LocalDate.now().plusDays(30));
                payment.setChildId(new ChildId(1L));
                
                assertThrows(IllegalArgumentException.class, () -> paymentService.createPayment(payment));
            }

            @Test
            void processPayment_ExistingId_ReturnsProcessedPayment() {
                PaymentId paymentId = new PaymentId(1L);
                Payment payment = new Payment();
                payment.setId(paymentId);
                payment.setStatus(PaymentStatus.PENDING);
                
                when(paymentRepositoryPort.findById(paymentId)).thenReturn(Optional.of(payment));
                when(paymentRepositoryPort.save(any(Payment.class))).thenReturn(payment);
                
                Payment result = paymentService.processPayment(paymentId, PaymentMethod.CREDIT_CARD);
                
                assertEquals(PaymentStatus.PAID, result.getStatus());
                assertEquals(PaymentMethod.CREDIT_CARD, result.getMethod());
                assertNotNull(result.getPaymentDate());
            }

            @Test
            void processPayment_NonExistingId_ThrowsException() {
                PaymentId paymentId = new PaymentId(999L);
                
                when(paymentRepositoryPort.findById(paymentId)).thenReturn(Optional.empty());
                
                assertThrows(PaymentNotFoundException.class, () -> paymentService.processPayment(paymentId, PaymentMethod.CREDIT_CARD));
            }

            @Test
            void getPaymentById_ExistingId_ReturnsPayment() {
                PaymentId paymentId = new PaymentId(1L);
                Payment payment = new Payment();
                payment.setId(paymentId);
                
                when(paymentRepositoryPort.findById(paymentId)).thenReturn(Optional.of(payment));
                
                Optional<Payment> result = paymentService.getPaymentById(paymentId);
                
                assertTrue(result.isPresent());
                assertEquals(paymentId, result.get().getId());
            }

            @Test
            void getPaymentsByChildId_ReturnsFilteredPayments() {
                ChildId childId = new ChildId(1L);
                List<Payment> payments = Arrays.asList(new Payment(), new Payment());
                
                when(paymentRepositoryPort.findByChildId(childId)).thenReturn(payments);
                
                List<Payment> result = paymentService.getPaymentsByChildId(childId);
                
                assertEquals(2, result.size());
            }

            @Test
            void getOverduePayments_ReturnsOverduePayments() {
                Payment overduePayment = new Payment();
                overduePayment.setDueDate(LocalDate.now().minusDays(10));
                overduePayment.setStatus(PaymentStatus.PENDING);
                
                Payment pendingPayment = new Payment();
                pendingPayment.setDueDate(LocalDate.now().plusDays(10));
                pendingPayment.setStatus(PaymentStatus.PENDING);
                
                List<Payment> pendingPayments = Arrays.asList(overduePayment, pendingPayment);
                
                when(paymentRepositoryPort.findByStatus(PaymentStatus.PENDING)).thenReturn(pendingPayments);
                
                List<Payment> result = paymentService.getOverduePayments();
                
                assertEquals(1, result.size());
                assertTrue(result.get(0).getDueDate().isBefore(LocalDate.now()));
            }

            @Test
            void updatePayment_ExistingId_ReturnsUpdatedPayment() {
                PaymentId paymentId = new PaymentId(1L);
                Payment existingPayment = new Payment();
                existingPayment.setId(paymentId);
                existingPayment.setAmount(new BigDecimal("100.00"));
                
                Payment updatedPayment = new Payment();
                updatedPayment.setAmount(new BigDecimal("150.00"));
                updatedPayment.setDueDate(LocalDate.now().plusDays(45));
                updatedPayment.setStatus(PaymentStatus.PAID);
                
                when(paymentRepositoryPort.findById(paymentId)).thenReturn(Optional.of(existingPayment));
                when(paymentRepositoryPort.save(any(Payment.class))).thenReturn(existingPayment);
                
                Payment result = paymentService.updatePayment(paymentId, updatedPayment);
                
                assertEquals(new BigDecimal("150.00"), result.getAmount());
                assertEquals(PaymentStatus.PAID, result.getStatus());
            }

            @Test
            void deletePayment_ValidId_CallsRepository() {
                PaymentId paymentId = new PaymentId(1L);
                
                paymentService.deletePayment(paymentId);
                
                verify(paymentRepositoryPort).deleteById(paymentId);
            }
            // -------------------------------
            return null; 
        } catch (Exception e) {
            log.error("Error en PaymentServiceTest: ", e);
            throw e;
        }
    }
}