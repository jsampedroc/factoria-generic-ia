package com.daycaremanagement.domain.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;
import java.util.*;
import java.time.*;
import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente ChildTest
 * POJO Entity managed by Factory
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ChildTest {

    // --- LOGIC INJECTED BY IA ---
    @Test
    void childCreation_ValidData_Success() {
        Child child = new Child();
        child.setId(new ChildId(1L));
        child.setFirstName("John");
        child.setLastName("Doe");
        child.setDateOfBirth(LocalDate.of(2020, 1, 1));
        child.setAllergies("None");
        child.setSpecialNeeds("None");
        child.setEnrollmentDate(LocalDate.now());
        child.setStatus(ChildStatus.ACTIVE);
        
        assertEquals(new ChildId(1L), child.getId());
        assertEquals("John", child.getFirstName());
        assertEquals("Doe", child.getLastName());
        assertEquals(LocalDate.of(2020, 1, 1), child.getDateOfBirth());
        assertEquals("None", child.getAllergies());
        assertEquals("None", child.getSpecialNeeds());
        assertNotNull(child.getEnrollmentDate());
        assertEquals(ChildStatus.ACTIVE, child.getStatus());
    }

    @Test
    void childSettersAndGetters_WorkCorrectly() {
        Child child = new Child();
        
        ChildId id = new ChildId(2L);
        child.setId(id);
        child.setFirstName("Jane");
        child.setLastName("Smith");
        LocalDate dob = LocalDate.of(2019, 5, 15);
        child.setDateOfBirth(dob);
        child.setAllergies("Peanuts");
        child.setSpecialNeeds("Speech therapy");
        LocalDate enrollment = LocalDate.of(2023, 9, 1);
        child.setEnrollmentDate(enrollment);
        child.setStatus(ChildStatus.INACTIVE);
        
        assertEquals(id, child.getId());
        assertEquals("Jane", child.getFirstName());
        assertEquals("Smith", child.getLastName());
        assertEquals(dob, child.getDateOfBirth());
        assertEquals("Peanuts", child.getAllergies());
        assertEquals("Speech therapy", child.getSpecialNeeds());
        assertEquals(enrollment, child.getEnrollmentDate());
        assertEquals(ChildStatus.INACTIVE, child.getStatus());
    }

    @Test
    void childWithNullValues_HandledCorrectly() {
        Child child = new Child();
        
        assertNull(child.getId());
        assertNull(child.getFirstName());
        assertNull(child.getLastName());
        assertNull(child.getDateOfBirth());
        assertNull(child.getAllergies());
        assertNull(child.getSpecialNeeds());
        assertNull(child.getEnrollmentDate());
        assertNull(child.getStatus());
    }

    @Test
    void childStatusEnum_ValuesCorrect() {
        assertEquals("ACTIVE", ChildStatus.ACTIVE.name());
        assertEquals("INACTIVE", ChildStatus.INACTIVE.name());
        assertEquals("GRADUATED", ChildStatus.GRADUATED.name());
        
        assertTrue(ChildStatus.ACTIVE.toString().contains("ACTIVE"));
    }

    @Test
    void childIdEquality_WorksCorrectly() {
        ChildId id1 = new ChildId(1L);
        ChildId id2 = new ChildId(1L);
        ChildId id3 = new ChildId(2L);
        
        assertEquals(id1, id2);
        assertNotEquals(id1, id3);
        assertEquals(id1.hashCode(), id2.hashCode());
        assertNotEquals(id1.hashCode(), id3.hashCode());
    }

    @Test
    void childIdToString_ContainsValue() {
        ChildId id = new ChildId(5L);
        String toString = id.toString();
        
        assertTrue(toString.contains("5"));
        assertTrue(toString.contains("ChildId"));
    }
    // ----------------------------

}