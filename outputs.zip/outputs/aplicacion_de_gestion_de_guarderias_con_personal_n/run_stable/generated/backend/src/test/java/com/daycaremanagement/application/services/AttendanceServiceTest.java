package com.daycaremanagement.application.services;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

// Forzamos los Value Objects del dominio que siempre fallan
import com.daycaremanagement.domain.valueobject.*;
import com.daycaremanagement.domain.model.*;

import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente: AttendanceServiceTest
 * Componente AttendanceServiceTest
 */
@Slf4j
@Component
public class AttendanceServiceTest {

    public Object execute(Map<String, Object> params) {
        log.info("Iniciando ejecución de AttendanceServiceTest");
        try {
            // --- LÓGICA INYECTADA POR IA ---
            @Test
            void recordAttendance_ValidData_ReturnsAttendance() {
                Attendance attendance = new Attendance();
                attendance.setChildId(new ChildId(1L));
                attendance.setDate(LocalDate.now());
                attendance.setCheckInTime(LocalTime.of(8, 0));
                attendance.setStatus(AttendanceStatus.PRESENT);
                
                when(attendanceRepositoryPort.save(any(Attendance.class))).thenReturn(attendance);
                
                Attendance result = attendanceService.recordAttendance(attendance);
                
                assertNotNull(result);
                assertEquals(AttendanceStatus.PRESENT, result.getStatus());
                verify(attendanceRepositoryPort).save(attendance);
            }

            @Test
            void recordAttendance_InvalidChildId_ThrowsException() {
                Attendance attendance = new Attendance();
                attendance.setChildId(null);
                attendance.setDate(LocalDate.now());
                
                assertThrows(IllegalArgumentException.class, () -> attendanceService.recordAttendance(attendance));
            }

            @Test
            void getAttendanceById_ExistingId_ReturnsAttendance() {
                AttendanceId attendanceId = new AttendanceId(1L);
                Attendance attendance = new Attendance();
                attendance.setId(attendanceId);
                
                when(attendanceRepositoryPort.findById(attendanceId)).thenReturn(Optional.of(attendance));
                
                Optional<Attendance> result = attendanceService.getAttendanceById(attendanceId);
                
                assertTrue(result.isPresent());
                assertEquals(attendanceId, result.get().getId());
            }

            @Test
            void getAttendanceByChildId_ReturnsAttendanceList() {
                ChildId childId = new ChildId(1L);
                List<Attendance> attendanceList = Arrays.asList(new Attendance(), new Attendance());
                
                when(attendanceRepositoryPort.findByChildId(childId)).thenReturn(attendanceList);
                
                List<Attendance> result = attendanceService.getAttendanceByChildId(childId);
                
                assertEquals(2, result.size());
            }

            @Test
            void getAttendanceByDate_ReturnsAttendanceList() {
                LocalDate date = LocalDate.now();
                List<Attendance> attendanceList = Arrays.asList(new Attendance(), new Attendance());
                
                when(attendanceRepositoryPort.findByDate(date)).thenReturn(attendanceList);
                
                List<Attendance> result = attendanceService.getAttendanceByDate(date);
                
                assertEquals(2, result.size());
            }

            @Test
            void getAttendanceByChildIdAndDate_ReturnsAttendanceList() {
                ChildId childId = new ChildId(1L);
                LocalDate date = LocalDate.now();
                List<Attendance> attendanceList = Arrays.asList(new Attendance());
                
                when(attendanceRepositoryPort.findByChildIdAndDate(childId, date)).thenReturn(attendanceList);
                
                List<Attendance> result = attendanceService.getAttendanceByChildIdAndDate(childId, date);
                
                assertEquals(1, result.size());
            }

            @Test
            void updateCheckOutTime_ExistingAttendance_ReturnsUpdatedAttendance() {
                AttendanceId attendanceId = new AttendanceId(1L);
                Attendance existingAttendance = new Attendance();
                existingAttendance.setId(attendanceId);
                existingAttendance.setCheckInTime(LocalTime.of(8, 0));
                
                LocalTime checkOutTime = LocalTime.of(16, 0);
                
                when(attendanceRepositoryPort.findById(attendanceId)).thenReturn(Optional.of(existingAttendance));
                when(attendanceRepositoryPort.save(any(Attendance.class))).thenReturn(existingAttendance);
                
                Attendance result = attendanceService.updateCheckOutTime(attendanceId, checkOutTime);
                
                assertEquals(checkOutTime, result.getCheckOutTime());
            }

            @Test
            void updateCheckOutTime_NonExistingId_ThrowsException() {
                AttendanceId attendanceId = new AttendanceId(999L);
                LocalTime checkOutTime = LocalTime.of(16, 0);
                
                when(attendanceRepositoryPort.findById(attendanceId)).thenReturn(Optional.empty());
                
                assertThrows(AttendanceNotFoundException.class, () -> attendanceService.updateCheckOutTime(attendanceId, checkOutTime));
            }

            @Test
            void deleteAttendance_ValidId_CallsRepository() {
                AttendanceId attendanceId = new AttendanceId(1L);
                
                attendanceService.deleteAttendance(attendanceId);
                
                verify(attendanceRepositoryPort).deleteById(attendanceId);
            }
            // -------------------------------
            return null; 
        } catch (Exception e) {
            log.error("Error en AttendanceServiceTest: ", e);
            throw e;
        }
    }
}