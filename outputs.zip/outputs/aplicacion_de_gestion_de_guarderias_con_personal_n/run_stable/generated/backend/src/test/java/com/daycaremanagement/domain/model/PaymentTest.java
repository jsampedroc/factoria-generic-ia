package com.daycaremanagement.domain.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;
import java.util.*;
import java.time.*;
import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente PaymentTest
 * POJO Entity managed by Factory
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentTest {

    // --- LOGIC INJECTED BY IA ---
    @Test
    void paymentCreation_ValidData_Success() {
        Payment payment = new Payment();
        payment.setId(new PaymentId(1L));
        payment.setAmount(new BigDecimal("100.00"));
        payment.setDueDate(LocalDate.now().plusDays(30));
        payment.setPaymentDate(LocalDate.now());
        payment.setStatus(PaymentStatus.PAID);
        payment.setMethod(PaymentMethod.CREDIT_CARD);
        payment.setInvoiceNumber("INV-001");
        payment.setChildId(new ChildId(1L));
        
        assertEquals(new PaymentId(1L), payment.getId());
        assertEquals(new BigDecimal("100.00"), payment.getAmount());
        assertNotNull(payment.getDueDate());
        assertNotNull(payment.getPaymentDate());
        assertEquals(PaymentStatus.PAID, payment.getStatus());
        assertEquals(PaymentMethod.CREDIT_CARD, payment.getMethod());
        assertEquals("INV-001", payment.getInvoiceNumber());
        assertEquals(new ChildId(1L), payment.getChildId());
    }

    @Test
    void paymentSettersAndGetters_WorkCorrectly() {
        Payment payment = new Payment();
        
        PaymentId id = new PaymentId(2L);
        payment.setId(id);
        BigDecimal amount = new BigDecimal("150.50");
        payment.setAmount(amount);
        LocalDate dueDate = LocalDate.of(2024, 12, 31);
        payment.setDueDate(dueDate);
        LocalDate paymentDate = LocalDate.of(2024, 12, 15);
        payment.setPaymentDate(paymentDate);
        payment.setStatus(PaymentStatus.PENDING);
        payment.setMethod(PaymentMethod.BANK_TRANSFER);
        payment.setInvoiceNumber("INV-002");
        ChildId childId = new ChildId(3L);
        payment.setChildId(childId);
        
        assertEquals(id, payment.getId());
        assertEquals(amount, payment.getAmount());
        assertEquals(dueDate, payment.getDueDate());
        assertEquals(paymentDate, payment.getPaymentDate());
        assertEquals(PaymentStatus.PENDING, payment.getStatus());
        assertEquals(PaymentMethod.BANK_TRANSFER, payment.getMethod());
        assertEquals("INV-002", payment.getInvoiceNumber());
        assertEquals(childId, payment.getChildId());
    }

    @Test
    void paymentWithNullValues_HandledCorrectly() {
        Payment payment = new Payment();
        
        assertNull(payment.getId());
        assertNull(payment.getAmount());
        assertNull(payment.getDueDate());
        assertNull(payment.getPaymentDate());
        assertNull(payment.getStatus());
        assertNull(payment.getMethod());
        assertNull(payment.getInvoiceNumber());
        assertNull(payment.getChildId());
    }

    @Test
    void paymentStatusEnum_ValuesCorrect() {
        assertEquals("PENDING", PaymentStatus.PENDING.name());
        assertEquals("PAID", PaymentStatus.PAID.name());
        assertEquals("OVERDUE", PaymentStatus.OVERDUE.name());
        assertEquals("CANCELLED", PaymentStatus.CANCELLED.name());
        
        assertTrue(PaymentStatus.PAID.toString().contains("PAID"));
    }

    @Test
    void paymentMethodEnum_ValuesCorrect() {
        assertEquals("CASH", PaymentMethod.CASH.name());
        assertEquals("CREDIT_CARD", PaymentMethod.CREDIT_CARD.name());
        assertEquals("BANK_TRANSFER", PaymentMethod.BANK_TRANSFER.name());
        assertEquals("CHECK", PaymentMethod.CHECK.name());
        
        assertTrue(PaymentMethod.CREDIT_CARD.toString().contains("CREDIT_CARD"));
    }

    @Test
    void paymentIdEquality_WorksCorrectly() {
        PaymentId id1 = new PaymentId(1L);
        PaymentId id2 = new PaymentId(1L);
        PaymentId id3 = new PaymentId(2L);
        
        assertEquals(id1, id2);
        assertNotEquals(id1, id3);
        assertEquals(id1.hashCode(), id2.hashCode());
        assertNotEquals(id1.hashCode(), id3.hashCode());
    }

    @Test
    void paymentIdToString_ContainsValue() {
        PaymentId id = new PaymentId(5L);
        String toString = id.toString();
        
        assertTrue(toString.contains("5"));
        assertTrue(toString.contains("PaymentId"));
    }

    @Test
    void paymentAmountComparison_WorksCorrectly() {
        Payment payment = new Payment();
        payment.setAmount(new BigDecimal("100.00"));
        
        assertTrue(payment.getAmount().compareTo(new BigDecimal("50.00")) > 0);
        assertTrue(payment.getAmount().compareTo(new BigDecimal("100.00")) == 0);
        assertTrue(payment.getAmount().compareTo(new BigDecimal("150.00")) < 0);
    }

    @Test
    void paymentDueDateValidation_WorksCorrectly() {
        Payment payment = new Payment();
        LocalDate pastDate = LocalDate.now().minusDays(10);
        LocalDate futureDate = LocalDate.now().plusDays(10);
        
        payment.setDueDate(pastDate);
        assertTrue(payment.getDueDate().isBefore(LocalDate.now()));
        
        payment.setDueDate(futureDate);
        assertTrue(payment.getDueDate().isAfter(LocalDate.now()));
    }
    // ----------------------------

}