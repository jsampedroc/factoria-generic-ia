package com.daycaremanagement.application.services;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

// Forzamos los Value Objects del dominio que siempre fallan
import com.daycaremanagement.domain.valueobject.*;
import com.daycaremanagement.domain.model.*;

import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente: ChildServiceTest
 * Componente ChildServiceTest
 */
@Slf4j
@Component
public class ChildServiceTest {

    public Object execute(Map<String, Object> params) {
        log.info("Iniciando ejecución de ChildServiceTest");
        try {
            // --- LÓGICA INYECTADA POR IA ---
            @Test
            void createChild_ValidData_ReturnsChild() {
                Child child = new Child();
                child.setFirstName("John");
                child.setLastName("Doe");
                child.setDateOfBirth(LocalDate.of(2020, 1, 1));
                
                when(childRepositoryPort.save(any(Child.class))).thenReturn(child);
                
                Child result = childService.createChild(child);
                
                assertNotNull(result);
                assertEquals(ChildStatus.ACTIVE, result.getStatus());
                assertNotNull(result.getEnrollmentDate());
                verify(childRepositoryPort).save(child);
            }

            @Test
            void createChild_InvalidFirstName_ThrowsException() {
                Child child = new Child();
                child.setFirstName("");
                child.setLastName("Doe");
                child.setDateOfBirth(LocalDate.of(2020, 1, 1));
                
                assertThrows(IllegalArgumentException.class, () -> childService.createChild(child));
            }

            @Test
            void getChildById_ExistingId_ReturnsChild() {
                ChildId childId = new ChildId(1L);
                Child child = new Child();
                child.setId(childId);
                
                when(childRepositoryPort.findById(childId)).thenReturn(Optional.of(child));
                
                Optional<Child> result = childService.getChildById(childId);
                
                assertTrue(result.isPresent());
                assertEquals(childId, result.get().getId());
            }

            @Test
            void getChildById_NonExistingId_ReturnsEmpty() {
                ChildId childId = new ChildId(999L);
                
                when(childRepositoryPort.findById(childId)).thenReturn(Optional.empty());
                
                Optional<Child> result = childService.getChildById(childId);
                
                assertFalse(result.isPresent());
            }

            @Test
            void getAllChildren_ReturnsChildrenList() {
                List<Child> children = Arrays.asList(new Child(), new Child());
                
                when(childRepositoryPort.findAll()).thenReturn(children);
                
                List<Child> result = childService.getAllChildren();
                
                assertEquals(2, result.size());
            }

            @Test
            void getChildrenByStatus_ReturnsFilteredChildren() {
                ChildStatus status = ChildStatus.ACTIVE;
                List<Child> children = Arrays.asList(new Child(), new Child());
                
                when(childRepositoryPort.findByStatus(status)).thenReturn(children);
                
                List<Child> result = childService.getChildrenByStatus(status);
                
                assertEquals(2, result.size());
            }

            @Test
            void updateChild_ExistingId_ReturnsUpdatedChild() {
                ChildId childId = new ChildId(1L);
                Child existingChild = new Child();
                existingChild.setId(childId);
                existingChild.setFirstName("Old");
                
                Child updatedChild = new Child();
                updatedChild.setFirstName("New");
                updatedChild.setLastName("Updated");
                updatedChild.setDateOfBirth(LocalDate.of(2020, 1, 1));
                
                when(childRepositoryPort.findById(childId)).thenReturn(Optional.of(existingChild));
                when(childRepositoryPort.save(any(Child.class))).thenReturn(existingChild);
                
                Child result = childService.updateChild(childId, updatedChild);
                
                assertEquals("New", result.getFirstName());
                assertEquals("Updated", result.getLastName());
            }

            @Test
            void updateChild_NonExistingId_ThrowsException() {
                ChildId childId = new ChildId(999L);
                Child updatedChild = new Child();
                
                when(childRepositoryPort.findById(childId)).thenReturn(Optional.empty());
                
                assertThrows(ChildNotFoundException.class, () -> childService.updateChild(childId, updatedChild));
            }

            @Test
            void deleteChild_ValidId_CallsRepository() {
                ChildId childId = new ChildId(1L);
                
                childService.deleteChild(childId);
                
                verify(childRepositoryPort).deleteById(childId);
            }
            // -------------------------------
            return null; 
        } catch (Exception e) {
            log.error("Error en ChildServiceTest: ", e);
            throw e;
        }
    }
}