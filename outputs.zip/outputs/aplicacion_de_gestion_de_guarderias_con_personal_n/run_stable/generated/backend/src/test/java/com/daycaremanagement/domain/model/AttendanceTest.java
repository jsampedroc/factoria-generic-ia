package com.daycaremanagement.domain.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;
import java.util.*;
import java.time.*;
import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente AttendanceTest
 * POJO Entity managed by Factory
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AttendanceTest {

    // --- LOGIC INJECTED BY IA ---
    @Test
    void attendanceCreation_ValidData_Success() {
        Attendance attendance = new Attendance();
        attendance.setId(new AttendanceId(1L));
        attendance.setChildId(new ChildId(100L));
        attendance.setDate(LocalDate.now());
        attendance.setCheckInTime(LocalTime.of(8, 30));
        attendance.setCheckOutTime(LocalTime.of(16, 0));
        attendance.setStatus(AttendanceStatus.PRESENT);
        
        assertEquals(new AttendanceId(1L), attendance.getId());
        assertEquals(new ChildId(100L), attendance.getChildId());
        assertEquals(LocalDate.now(), attendance.getDate());
        assertEquals(LocalTime.of(8, 30), attendance.getCheckInTime());
        assertEquals(LocalTime.of(16, 0), attendance.getCheckOutTime());
        assertEquals(AttendanceStatus.PRESENT, attendance.getStatus());
    }

    @Test
    void attendanceSettersAndGetters_WorkCorrectly() {
        Attendance attendance = new Attendance();
        
        AttendanceId id = new AttendanceId(2L);
        attendance.setId(id);
        ChildId childId = new ChildId(200L);
        attendance.setChildId(childId);
        LocalDate date = LocalDate.of(2024, 1, 15);
        attendance.setDate(date);
        LocalTime checkIn = LocalTime.of(9, 0);
        attendance.setCheckInTime(checkIn);
        LocalTime checkOut = LocalTime.of(17, 30);
        attendance.setCheckOutTime(checkOut);
        attendance.setStatus(AttendanceStatus.ABSENT);
        
        assertEquals(id, attendance.getId());
        assertEquals(childId, attendance.getChildId());
        assertEquals(date, attendance.getDate());
        assertEquals(checkIn, attendance.getCheckInTime());
        assertEquals(checkOut, attendance.getCheckOutTime());
        assertEquals(AttendanceStatus.ABSENT, attendance.getStatus());
    }

    @Test
    void attendanceWithNullValues_HandledCorrectly() {
        Attendance attendance = new Attendance();
        
        assertNull(attendance.getId());
        assertNull(attendance.getChildId());
        assertNull(attendance.getDate());
        assertNull(attendance.getCheckInTime());
        assertNull(attendance.getCheckOutTime());
        assertNull(attendance.getStatus());
    }

    @Test
    void attendanceStatusEnum_ValuesCorrect() {
        assertEquals("PRESENT", AttendanceStatus.PRESENT.name());
        assertEquals("ABSENT", AttendanceStatus.ABSENT.name());
        assertEquals("LATE", AttendanceStatus.LATE.name());
        assertEquals("EARLY_DISMISSAL", AttendanceStatus.EARLY_DISMISSAL.name());
        
        assertTrue(AttendanceStatus.PRESENT.toString().contains("PRESENT"));
    }

    @Test
    void attendanceIdEquality_WorksCorrectly() {
        AttendanceId id1 = new AttendanceId(1L);
        AttendanceId id2 = new AttendanceId(1L);
        AttendanceId id3 = new AttendanceId(2L);
        
        assertEquals(id1, id2);
        assertNotEquals(id1, id3);
        assertEquals(id1.hashCode(), id2.hashCode());
        assertNotEquals(id1.hashCode(), id3.hashCode());
    }

    @Test
    void attendanceIdToString_ContainsValue() {
        AttendanceId id = new AttendanceId(5L);
        String toString = id.toString();
        
        assertTrue(toString.contains("5"));
        assertTrue(toString.contains("AttendanceId"));
    }
    // ----------------------------

}