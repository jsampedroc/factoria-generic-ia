package com.daycaremanagement.application.services;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

// Forzamos los Value Objects del dominio que siempre fallan
import com.daycaremanagement.domain.valueobject.*;
import com.daycaremanagement.domain.model.*;

import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente: StaffServiceTest
 * Componente StaffServiceTest
 */
@Slf4j
@Component
public class StaffServiceTest {

    public Object execute(Map<String, Object> params) {
        log.info("Iniciando ejecución de StaffServiceTest");
        try {
            // --- LÓGICA INYECTADA POR IA ---
            @Test
            void createStaff_ValidData_ReturnsStaff() {
                Staff staff = new Staff();
                staff.setFirstName("John");
                staff.setLastName("Doe");
                staff.setRole(StaffRole.TEACHER);
                staff.setContactInfo(new ContactInfo());
                
                when(staffRepositoryPort.save(any(Staff.class))).thenReturn(staff);
                
                Staff result = staffService.createStaff(staff);
                
                assertNotNull(result);
                assertEquals(StaffStatus.ACTIVE, result.getStatus());
                assertNotNull(result.getHireDate());
                verify(staffRepositoryPort).save(staff);
            }

            @Test
            void createStaff_InvalidFirstName_ThrowsException() {
                Staff staff = new Staff();
                staff.setFirstName("");
                staff.setLastName("Doe");
                staff.setRole(StaffRole.TEACHER);
                staff.setContactInfo(new ContactInfo());
                
                assertThrows(IllegalArgumentException.class, () -> staffService.createStaff(staff));
            }

            @Test
            void getStaffById_ExistingId_ReturnsStaff() {
                StaffId staffId = new StaffId(1L);
                Staff staff = new Staff();
                staff.setId(staffId);
                
                when(staffRepositoryPort.findById(staffId)).thenReturn(Optional.of(staff));
                
                Optional<Staff> result = staffService.getStaffById(staffId);
                
                assertTrue(result.isPresent());
                assertEquals(staffId, result.get().getId());
            }

            @Test
            void getStaffById_NonExistingId_ReturnsEmpty() {
                StaffId staffId = new StaffId(999L);
                
                when(staffRepositoryPort.findById(staffId)).thenReturn(Optional.empty());
                
                Optional<Staff> result = staffService.getStaffById(staffId);
                
                assertFalse(result.isPresent());
            }

            @Test
            void getAllStaff_ReturnsStaffList() {
                List<Staff> staffList = Arrays.asList(new Staff(), new Staff());
                
                when(staffRepositoryPort.findAll()).thenReturn(staffList);
                
                List<Staff> result = staffService.getAllStaff();
                
                assertEquals(2, result.size());
            }

            @Test
            void getStaffByRole_ReturnsFilteredStaff() {
                StaffRole role = StaffRole.TEACHER;
                List<Staff> staffList = Arrays.asList(new Staff(), new Staff());
                
                when(staffRepositoryPort.findByRole(role)).thenReturn(staffList);
                
                List<Staff> result = staffService.getStaffByRole(role);
                
                assertEquals(2, result.size());
            }

            @Test
            void getStaffByStatus_ReturnsFilteredStaff() {
                StaffStatus status = StaffStatus.ACTIVE;
                List<Staff> staffList = Arrays.asList(new Staff(), new Staff());
                
                when(staffRepositoryPort.findByStatus(status)).thenReturn(staffList);
                
                List<Staff> result = staffService.getStaffByStatus(status);
                
                assertEquals(2, result.size());
            }

            @Test
            void getStaffByRoleAndStatus_ReturnsFilteredStaff() {
                StaffRole role = StaffRole.TEACHER;
                StaffStatus status = StaffStatus.ACTIVE;
                List<Staff> staffList = Arrays.asList(new Staff(), new Staff());
                
                when(staffRepositoryPort.findByRoleAndStatus(role, status)).thenReturn(staffList);
                
                List<Staff> result = staffService.getStaffByRoleAndStatus(role, status);
                
                assertEquals(2, result.size());
            }

            @Test
            void updateStaff_ExistingId_ReturnsUpdatedStaff() {
                StaffId staffId = new StaffId(1L);
                Staff existingStaff = new Staff();
                existingStaff.setId(staffId);
                existingStaff.setFirstName("Old");
                
                Staff updatedStaff = new Staff();
                updatedStaff.setFirstName("New");
                updatedStaff.setLastName("Updated");
                updatedStaff.setRole(StaffRole.ADMIN);
                updatedStaff.setContactInfo(new ContactInfo());
                
                when(staffRepositoryPort.findById(staffId)).thenReturn(Optional.of(existingStaff));
                when(staffRepositoryPort.save(any(Staff.class))).thenReturn(existingStaff);
                
                Staff result = staffService.updateStaff(staffId, updatedStaff);
                
                assertEquals("New", result.getFirstName());
                assertEquals("Updated", result.getLastName());
                assertEquals(StaffRole.ADMIN, result.getRole());
            }

            @Test
            void updateStaff_NonExistingId_ThrowsException() {
                StaffId staffId = new StaffId(999L);
                Staff updatedStaff = new Staff();
                
                when(staffRepositoryPort.findById(staffId)).thenReturn(Optional.empty());
                
                assertThrows(StaffNotFoundException.class, () -> staffService.updateStaff(staffId, updatedStaff));
            }

            @Test
            void deleteStaff_ValidId_CallsRepository() {
                StaffId staffId = new StaffId(1L);
                
                staffService.deleteStaff(staffId);
                
                verify(staffRepositoryPort).deleteById(staffId);
            }
            // -------------------------------
            return null; 
        } catch (Exception e) {
            log.error("Error en StaffServiceTest: ", e);
            throw e;
        }
    }
}