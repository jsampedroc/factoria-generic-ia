package com.daycaremanagement.domain.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;
import java.util.*;
import java.time.*;
import com.daycaremanagement.domain.valueobject.*;

/**
 * Componente StaffTest
 * POJO Entity managed by Factory
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StaffTest {

    // --- LOGIC INJECTED BY IA ---
    @Test
    void staffCreation_ValidData_Success() {
        Staff staff = new Staff();
        staff.setId(new StaffId(1L));
        staff.setFirstName("John");
        staff.setLastName("Doe");
        staff.setRole(StaffRole.TEACHER);
        staff.setHireDate(LocalDate.now());
        staff.setContactInfo(new ContactInfo());
        staff.setStatus(StaffStatus.ACTIVE);
        
        assertEquals(new StaffId(1L), staff.getId());
        assertEquals("John", staff.getFirstName());
        assertEquals("Doe", staff.getLastName());
        assertEquals(StaffRole.TEACHER, staff.getRole());
        assertNotNull(staff.getHireDate());
        assertNotNull(staff.getContactInfo());
        assertEquals(StaffStatus.ACTIVE, staff.getStatus());
    }

    @Test
    void staffSettersAndGetters_WorkCorrectly() {
        Staff staff = new Staff();
        
        StaffId id = new StaffId(2L);
        staff.setId(id);
        staff.setFirstName("Jane");
        staff.setLastName("Smith");
        staff.setRole(StaffRole.ADMIN);
        LocalDate hireDate = LocalDate.of(2023, 1, 15);
        staff.setHireDate(hireDate);
        ContactInfo contactInfo = new ContactInfo();
        staff.setContactInfo(contactInfo);
        staff.setStatus(StaffStatus.INACTIVE);
        
        assertEquals(id, staff.getId());
        assertEquals("Jane", staff.getFirstName());
        assertEquals("Smith", staff.getLastName());
        assertEquals(StaffRole.ADMIN, staff.getRole());
        assertEquals(hireDate, staff.getHireDate());
        assertEquals(contactInfo, staff.getContactInfo());
        assertEquals(StaffStatus.INACTIVE, staff.getStatus());
    }

    @Test
    void staffWithNullValues_HandledCorrectly() {
        Staff staff = new Staff();
        
        assertNull(staff.getId());
        assertNull(staff.getFirstName());
        assertNull(staff.getLastName());
        assertNull(staff.getRole());
        assertNull(staff.getHireDate());
        assertNull(staff.getContactInfo());
        assertNull(staff.getStatus());
    }

    @Test
    void staffRoleEnum_ValuesCorrect() {
        assertEquals("TEACHER", StaffRole.TEACHER.name());
        assertEquals("ADMIN", StaffRole.ADMIN.name());
        assertEquals("ASSISTANT", StaffRole.ASSISTANT.name());
        assertEquals("NURSE", StaffRole.NURSE.name());
        
        assertTrue(StaffRole.TEACHER.toString().contains("TEACHER"));
    }

    @Test
    void staffStatusEnum_ValuesCorrect() {
        assertEquals("ACTIVE", StaffStatus.ACTIVE.name());
        assertEquals("INACTIVE", StaffStatus.INACTIVE.name());
        assertEquals("ON_LEAVE", StaffStatus.ON_LEAVE.name());
        
        assertTrue(StaffStatus.ACTIVE.toString().contains("ACTIVE"));
    }

    @Test
    void staffIdEquality_WorksCorrectly() {
        StaffId id1 = new StaffId(1L);
        StaffId id2 = new StaffId(1L);
        StaffId id3 = new StaffId(2L);
        
        assertEquals(id1, id2);
        assertNotEquals(id1, id3);
        assertEquals(id1.hashCode(), id2.hashCode());
        assertNotEquals(id1.hashCode(), id3.hashCode());
    }

    @Test
    void staffIdToString_ContainsValue() {
        StaffId id = new StaffId(5L);
        String toString = id.toString();
        
        assertTrue(toString.contains("5"));
        assertTrue(toString.contains("StaffId"));
    }
    // ----------------------------

}