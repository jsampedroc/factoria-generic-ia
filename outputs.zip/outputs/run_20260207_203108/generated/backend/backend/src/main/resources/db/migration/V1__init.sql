-- Flyway migration V1: Initial schema

-- Example table for a generic entity
-- Replace with actual entities from domain_model
CREATE TABLE IF NOT EXISTS example_entity (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Add more tables for each core entity as needed
-- For now, this is a placeholder to ensure Flyway runs successfully.