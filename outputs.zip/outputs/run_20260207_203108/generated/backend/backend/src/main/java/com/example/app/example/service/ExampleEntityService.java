package com.example.app.example.service;

import com.example.app.example.model.ExampleEntity;
import com.example.app.example.repo.ExampleEntityRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ExampleEntityService {
    private final ExampleEntityRepository repository;

    public List<ExampleEntity> findAll() {
        return repository.findAll();
    }

    public ExampleEntity findById(UUID id) {
        return repository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("ExampleEntity not found with id: " + id));
    }

    @Transactional
    public ExampleEntity create(ExampleEntity entity) {
        return repository.save(entity);
    }

    @Transactional
    public ExampleEntity update(UUID id, ExampleEntity entity) {
        ExampleEntity existing = findById(id);
        existing.setName(entity.getName());
        existing.setDescription(entity.getDescription());
        return repository.save(existing);
    }

    @Transactional
    public void delete(UUID id) {
        ExampleEntity entity = findById(id);
        repository.delete(entity);
    }
}