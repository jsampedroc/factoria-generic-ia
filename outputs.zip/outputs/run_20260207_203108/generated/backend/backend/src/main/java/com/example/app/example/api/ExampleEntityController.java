package com.example.app.example.api;

import com.example.app.example.model.ExampleEntity;
import com.example.app.example.service.ExampleEntityService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/example-entities")
@RequiredArgsConstructor
public class ExampleEntityController {
    private final ExampleEntityService service;

    @GetMapping
    public ResponseEntity<List<ExampleEntity>> getAll() {
        return ResponseEntity.ok(service.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ExampleEntity> getById(@PathVariable UUID id) {
        return ResponseEntity.ok(service.findById(id));
    }

    @PostMapping
    public ResponseEntity<ExampleEntity> create(@Valid @RequestBody ExampleEntity entity) {
        return new ResponseEntity<>(service.create(entity), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ExampleEntity> update(@PathVariable UUID id, @Valid @RequestBody ExampleEntity entity) {
        return ResponseEntity.ok(service.update(id, entity));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable UUID id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}