package com.example.app.example.repo;

import com.example.app.example.model.ExampleEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface ExampleEntityRepository extends JpaRepository<ExampleEntity, UUID> {
}